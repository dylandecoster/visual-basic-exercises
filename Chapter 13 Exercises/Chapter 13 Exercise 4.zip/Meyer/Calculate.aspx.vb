﻿
Partial Class About
    Inherits Page

    Protected Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        Dim totalItems As Integer
        totalItems = CInt(txtDoughnuts.Text) + CInt(txtMuffins.Text)
        Me.lblItems.Text = totalItems
        Me.lblTotal.Text = "$" + ((txtDoughnuts.Text * 0.5) + (txtMuffins.Text * 0.75)).ToString("N2")
    End Sub
End Class
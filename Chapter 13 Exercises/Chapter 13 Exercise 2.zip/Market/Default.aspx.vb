﻿
Partial Class _Default
    Inherits Page

End Class
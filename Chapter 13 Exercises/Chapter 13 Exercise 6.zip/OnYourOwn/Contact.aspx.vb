﻿
Partial Class Contact
    Inherits Page

    Protected Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        Me.lblTotal.Text = CInt(txtApples.Text) + CInt(txtOranges.Text)
    End Sub
End Class
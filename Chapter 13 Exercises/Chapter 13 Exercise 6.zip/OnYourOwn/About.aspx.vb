﻿
Partial Class About
    Inherits Page

End Class
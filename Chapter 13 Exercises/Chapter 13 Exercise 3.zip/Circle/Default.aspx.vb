﻿
Partial Class _Default
    Inherits Page
    Protected Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        Me.lblArea.Text = (3.14 * (Me.txtRadius.Text * Me.txtRadius.Text)).ToString("N1")
    End Sub
End Class
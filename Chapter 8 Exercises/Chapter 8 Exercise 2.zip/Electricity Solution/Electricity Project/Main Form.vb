﻿' Name:         Electricity Project
' Purpose:      Calculate the average monthly electric bill.
' Programmer:   Dylan DeCoster on 10/28/19

Option Explicit On
Option Strict On
Option Infer Off

Public Class frmMain
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        ' Display the average monthly cost.

        Dim dblMonthly() As Double = {141.71, 156.75, 179.25, 141.71, 130.19, 115.05,
                                       95.65, 86.78, 85.45, 79.99, 98.45, 126.78}

        'For each cost in the array
        For Each cost As Double In dblMonthly
            Dim avg As Double
            'Adds up all of the costs
            avg += cost

            'Gets the costs and divides by the amount of numbers to get the average
            Me.lblAvg.Text = "$" + (avg / dblMonthly.Length).ToString("N2")
        Next cost
    End Sub
End Class

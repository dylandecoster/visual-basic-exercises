' Name:         Gross Pay Project
' Purpose:      Displays an employee's gross pay.
' Programmer:   Dylan DeCoster on 10/29/19

Option Explicit On
Option Strict On
Option Infer Off

Public Class frmMain

    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles Me.Load
        ' Selects the first pay code in the list box.

        lstCodes.SelectedIndex = 0
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub ClearGross(sender As Object, e As EventArgs) Handles lstCodes.SelectedIndexChanged, txtHours.TextChanged
        lblGross.Text = String.Empty
    End Sub

    Private Sub txtHours_Enter(sender As Object, e As EventArgs) Handles txtHours.Enter
        txtHours.SelectAll()
    End Sub

    Private Sub txtHours_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtHours.KeyPress
        ' Accept only numbers, the period, and the Backspace key.

        If (e.KeyChar < "0" OrElse e.KeyChar > "9") AndAlso e.KeyChar <> "." AndAlso e.KeyChar <> ControlChars.Back Then
            e.Handled = True
        End If
    End Sub

    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        'Makes an array that stores all the pay rates
        Dim payRate() As Double = {10.5, 12.5, 14.25, 15.75, 17.65}

        Dim hours As Double = Val(Me.txtHours.Text)
        Dim extra As Double
        Dim total As Double

        'Gets the amount of extra hours
        If (hours > 40) Then
            extra = hours - 40
            hours = 40
        End If

        'Checks which pay code is selected and calculates accordingly
        Select Case True
            Case Me.lstCodes.SelectedIndex = 0
                'Calculates time and a half
                extra *= payRate(0) * 0.5
                'Calculates the base pay
                total = hours * payRate(0)
            Case Me.lstCodes.SelectedIndex = 1
                extra *= payRate(1) * 0.5
                total = hours * payRate(1)
            Case Me.lstCodes.SelectedIndex = 2
                extra *= payRate(2) * 0.5
                total = hours * payRate(2)
            Case Me.lstCodes.SelectedIndex = 3
                extra *= payRate(3) * 0.5
                total = hours * payRate(3)
            Case Me.lstCodes.SelectedIndex = 4
                extra *= payRate(4) * 0.5
                total = hours * payRate(4)
        End Select

        'Prints and formats everything
        Me.lblGross.Text = "$" + (total + extra).ToString("N2")
    End Sub
End Class

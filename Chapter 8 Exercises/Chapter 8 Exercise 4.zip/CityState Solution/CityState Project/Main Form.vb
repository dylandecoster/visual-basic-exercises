﻿' Name:         CityState Project
' Purpose:      Display a city name followed by a comma, a space, and the state name.
' Programmer:   Dylan DeCoster on 10/29/19

Option Explicit On
Option Strict On
Option Infer Off

Public Class frmMain
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnDisplay_Click(sender As Object, e As EventArgs) Handles btnDisplay.Click
        ' Displays the contents of the arrays using this format: city, state.

        Dim strStates() As String = {"Alabama", "Alaska", "Arizona", "Arkansas", "California"}
        Dim strCities() As String = {"Montgomery", "Juneau", "Phoenix", "Little Rock", "Sacramento"}

        'If there is 5 or less items in the list box
        If (Me.lstCitiesAndStates.Items.Count <= 4) Then
            'Repeats 5 times
            For intIndex As Integer = 0 To 4
                'Adds the corresponding city and state to the list box
                Me.lstCitiesAndStates.Items.Add(strCities(intIndex) + ", " + strStates(intIndex))
            Next intIndex
        End If
    End Sub

    'Clears the list box
    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.lstCitiesAndStates.Items.Clear()
    End Sub
End Class

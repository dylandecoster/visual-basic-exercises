﻿' Name:         Professor Juarez Project
' Purpose:      Display the names and number of students earning a specific grade.
' Programmer:   Dylan DeCoster on 10/29/19
Option Explicit On
Option Strict On
Option Infer Off

Public Class frmMain
   Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnDisplay_Click(sender As Object, e As EventArgs) Handles btnDisplay.Click
        ' Display the names and number of students earning a specific grade.

        Dim strNames() As String = {"Helen", "Peter", "Yolanda", "Carl", "Jennifer", "Charles", "Addison", "Aiden", "Treyson", "Sydney", "Jacob", "Nancy", "George", "Ursula", "Jack"}
        Dim strGrades() As String = {"A", "B", "B", "A", "D", "F", "A", "B", "A", "B", "F", "C", "C", "B", "D"}
        Dim gradeCount As Integer

        'Clears the existing names
        Me.lstNames.Items.Clear()

        'Repeats the length of the arrays length
        For intIndex As Integer = 0 To strNames.Length - 1
            'If the array item is the same as the selected index
            If strGrades(intIndex) Is Me.lstGrades.SelectedItem Then
                'Adds one to grade
                gradeCount += 1
                'Gets the gradeholder and adds it to the list
                Me.lstNames.Items.Add(strNames(intIndex))
            End If
        Next intIndex

        'Prints the grade count
        Me.lblNumber.Text = gradeCount.ToString
    End Sub

    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.lstGrades.SelectedIndex = 0
    End Sub

    'Clears everything
    Private Sub Clear(sender As Object, e As EventArgs) Handles lstGrades.SelectedIndexChanged
        Me.lstNames.Items.Clear()
    End Sub
End Class

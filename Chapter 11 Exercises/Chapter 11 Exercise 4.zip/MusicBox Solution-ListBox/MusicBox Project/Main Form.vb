﻿' Name:         MusicBox Project
' Purpose:      Displays the records stored in a dataset.
' Programmer:   Dylan DeCoster on 11/11/19

Option Explicit On
Option Strict On
Option Infer Off

Public Class frmMain
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'MusicBoxesDataSet.Boxes' table. You can move, or remove it, as needed.
        Me.BoxesTableAdapter.Fill(Me.MusicBoxesDataSet.Boxes)

    End Sub
End Class

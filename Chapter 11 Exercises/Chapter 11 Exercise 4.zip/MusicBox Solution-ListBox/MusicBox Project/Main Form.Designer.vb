﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblSong = New System.Windows.Forms.Label()
        Me.lblSource = New System.Windows.Forms.Label()
        Me.lblShape = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lstId = New System.Windows.Forms.ListBox()
        Me.MusicBoxesDataSet = New MusicBox_Project.MusicBoxesDataSet()
        Me.BoxesBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.BoxesTableAdapter = New MusicBox_Project.MusicBoxesDataSetTableAdapters.BoxesTableAdapter()
        Me.TableAdapterManager = New MusicBox_Project.MusicBoxesDataSetTableAdapters.TableAdapterManager()
        CType(Me.MusicBoxesDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BoxesBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblSong
        '
        Me.lblSong.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSong.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.BoxesBindingSource, "Song", True))
        Me.lblSong.Location = New System.Drawing.Point(340, 37)
        Me.lblSong.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblSong.Name = "lblSong"
        Me.lblSong.Size = New System.Drawing.Size(238, 24)
        Me.lblSong.TabIndex = 8
        Me.lblSong.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblSource
        '
        Me.lblSource.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSource.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.BoxesBindingSource, "Source", True))
        Me.lblSource.Location = New System.Drawing.Point(232, 37)
        Me.lblSource.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblSource.Name = "lblSource"
        Me.lblSource.Size = New System.Drawing.Size(87, 24)
        Me.lblSource.TabIndex = 6
        Me.lblSource.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblShape
        '
        Me.lblShape.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblShape.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.BoxesBindingSource, "Shape", True))
        Me.lblShape.Location = New System.Drawing.Point(101, 37)
        Me.lblShape.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblShape.Name = "lblShape"
        Me.lblShape.Size = New System.Drawing.Size(105, 24)
        Me.lblShape.TabIndex = 4
        Me.lblShape.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(336, 17)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(37, 15)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Song:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(228, 17)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(46, 15)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Source:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(97, 17)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(42, 15)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Shape:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(15, 17)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(21, 15)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "&ID:"
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(503, 94)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 31)
        Me.btnExit.TabIndex = 2
        Me.btnExit.Text = "E&xit"
        '
        'lstId
        '
        Me.lstId.DataSource = Me.BoxesBindingSource
        Me.lstId.DisplayMember = "ID"
        Me.lstId.FormattingEnabled = True
        Me.lstId.ItemHeight = 15
        Me.lstId.Location = New System.Drawing.Point(18, 37)
        Me.lstId.Name = "lstId"
        Me.lstId.Size = New System.Drawing.Size(41, 79)
        Me.lstId.TabIndex = 1
        '
        'MusicBoxesDataSet
        '
        Me.MusicBoxesDataSet.DataSetName = "MusicBoxesDataSet"
        Me.MusicBoxesDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'BoxesBindingSource
        '
        Me.BoxesBindingSource.DataMember = "Boxes"
        Me.BoxesBindingSource.DataSource = Me.MusicBoxesDataSet
        '
        'BoxesTableAdapter
        '
        Me.BoxesTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.BoxesTableAdapter = Me.BoxesTableAdapter
        Me.TableAdapterManager.UpdateOrder = MusicBox_Project.MusicBoxesDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(595, 152)
        Me.Controls.Add(Me.lstId)
        Me.Controls.Add(Me.lblSong)
        Me.Controls.Add(Me.lblSource)
        Me.Controls.Add(Me.lblShape)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnExit)
        Me.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.MaximizeBox = False
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Music Box"
        CType(Me.MusicBoxesDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BoxesBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblSong As System.Windows.Forms.Label
    Friend WithEvents lblSource As System.Windows.Forms.Label
    Friend WithEvents lblShape As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents lstId As System.Windows.Forms.ListBox
    Friend WithEvents MusicBoxesDataSet As MusicBoxesDataSet
    Friend WithEvents BoxesBindingSource As BindingSource
    Friend WithEvents BoxesTableAdapter As MusicBoxesDataSetTableAdapters.BoxesTableAdapter
    Friend WithEvents TableAdapterManager As MusicBoxesDataSetTableAdapters.TableAdapterManager
End Class

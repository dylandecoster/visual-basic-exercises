﻿Public Class frmMain
    Private Sub GradesBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles GradesBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.GradesBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.GradesDataSet)

    End Sub

    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'GradesDataSet.Grades' table. You can move, or remove it, as needed.
        Me.GradesTableAdapter.Fill(Me.GradesDataSet.Grades)
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        'TODO: This line of code loads data into the 'GradesDataSet.Failing' table. You can move, or remove it, as needed.
        Me.FailingTableAdapter.Fill(Me.GradesDataSet.Failing)
    End Sub
End Class

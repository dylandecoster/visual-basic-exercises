﻿' Name:         Course Info Project
' Purpose:      Display all records or only those for a specific grade.
' Programmer:   <your name> on <current date>

Option Explicit On
Option Strict On
Option Infer Off

Public Class frmMain
    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'MyCoursesDataSet.Courses' table. You can move, or remove it, as needed.
        Me.CoursesTableAdapter.Fill(Me.MyCoursesDataSet.Courses)

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnDisplay_Click(sender As Object, e As EventArgs) Handles btnDisplay.Click
        ' Display all records or only those for a specific grade.

        If radAll.Checked Then
            CoursesTableAdapter.Fill(MyCoursesDataSet.Courses)
            txtGrade.Text = String.Empty
            lblCount.Text = String.Empty
        Else
            If txtGrade.Text.Trim = String.Empty Then
                MessageBox.Show("Please enter the grade.", "Course Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                CoursesTableAdapter.FillByGrade(MyCoursesDataSet.Courses, txtGrade.Text.Trim)
                NumGradeTableAdapter.FillNumGrade(MyCoursesDataSet.NumGrade)
            End If
        End If
    End Sub

    Private Sub radAll_Click(sender As Object, e As EventArgs) Handles radAll.Click
        txtGrade.Text = String.Empty
        lblCount.Text = String.Empty
    End Sub
End Class

﻿Public Class frmMain
    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'EllingtonDataSet.Sales2019' table. You can move, or remove it, as needed.
        Me.Sales2019TableAdapter.Fill(Me.EllingtonDataSet.Sales2019)

    End Sub
End Class

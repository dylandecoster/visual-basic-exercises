﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.MonthDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.JacksonvilleDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MiamiDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TampaDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TotalDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Sales2019BindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.EllingtonDataSet = New Ellington_Project.EllingtonDataSet()
        Me.Sales2019TableAdapter = New Ellington_Project.EllingtonDataSetTableAdapters.Sales2019TableAdapter()
        Me.TableAdapterManager = New Ellington_Project.EllingtonDataSetTableAdapters.TableAdapterManager()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblJacksonville = New System.Windows.Forms.Label()
        Me.lblMiami = New System.Windows.Forms.Label()
        Me.lblTampa = New System.Windows.Forms.Label()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Sales2019BindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EllingtonDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.MonthDataGridViewTextBoxColumn, Me.JacksonvilleDataGridViewTextBoxColumn, Me.MiamiDataGridViewTextBoxColumn, Me.TampaDataGridViewTextBoxColumn, Me.TotalDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.Sales2019BindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(0, 0)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.Size = New System.Drawing.Size(414, 176)
        Me.DataGridView1.TabIndex = 0
        '
        'MonthDataGridViewTextBoxColumn
        '
        Me.MonthDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader
        Me.MonthDataGridViewTextBoxColumn.DataPropertyName = "Month"
        Me.MonthDataGridViewTextBoxColumn.HeaderText = "Month"
        Me.MonthDataGridViewTextBoxColumn.Name = "MonthDataGridViewTextBoxColumn"
        Me.MonthDataGridViewTextBoxColumn.ReadOnly = True
        Me.MonthDataGridViewTextBoxColumn.Width = 68
        '
        'JacksonvilleDataGridViewTextBoxColumn
        '
        Me.JacksonvilleDataGridViewTextBoxColumn.DataPropertyName = "Jacksonville"
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle1.Format = "N0"
        DataGridViewCellStyle1.NullValue = Nothing
        Me.JacksonvilleDataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle1
        Me.JacksonvilleDataGridViewTextBoxColumn.HeaderText = "Jacksonville"
        Me.JacksonvilleDataGridViewTextBoxColumn.Name = "JacksonvilleDataGridViewTextBoxColumn"
        Me.JacksonvilleDataGridViewTextBoxColumn.ReadOnly = True
        '
        'MiamiDataGridViewTextBoxColumn
        '
        Me.MiamiDataGridViewTextBoxColumn.DataPropertyName = "Miami"
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle2.Format = "N0"
        DataGridViewCellStyle2.NullValue = Nothing
        Me.MiamiDataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle2
        Me.MiamiDataGridViewTextBoxColumn.HeaderText = "Miami"
        Me.MiamiDataGridViewTextBoxColumn.Name = "MiamiDataGridViewTextBoxColumn"
        Me.MiamiDataGridViewTextBoxColumn.ReadOnly = True
        '
        'TampaDataGridViewTextBoxColumn
        '
        Me.TampaDataGridViewTextBoxColumn.DataPropertyName = "Tampa"
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle3.Format = "N0"
        DataGridViewCellStyle3.NullValue = Nothing
        Me.TampaDataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle3
        Me.TampaDataGridViewTextBoxColumn.HeaderText = "Tampa"
        Me.TampaDataGridViewTextBoxColumn.Name = "TampaDataGridViewTextBoxColumn"
        Me.TampaDataGridViewTextBoxColumn.ReadOnly = True
        '
        'TotalDataGridViewTextBoxColumn
        '
        Me.TotalDataGridViewTextBoxColumn.DataPropertyName = "Total"
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle4.Format = "N0"
        DataGridViewCellStyle4.NullValue = Nothing
        Me.TotalDataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle4
        Me.TotalDataGridViewTextBoxColumn.HeaderText = "Total"
        Me.TotalDataGridViewTextBoxColumn.Name = "TotalDataGridViewTextBoxColumn"
        Me.TotalDataGridViewTextBoxColumn.ReadOnly = True
        '
        'Sales2019BindingSource
        '
        Me.Sales2019BindingSource.DataMember = "Sales2019"
        Me.Sales2019BindingSource.DataSource = Me.EllingtonDataSet
        '
        'EllingtonDataSet
        '
        Me.EllingtonDataSet.DataSetName = "EllingtonDataSet"
        Me.EllingtonDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Sales2019TableAdapter
        '
        Me.Sales2019TableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.Sales2019TableAdapter = Me.Sales2019TableAdapter
        Me.TableAdapterManager.UpdateOrder = Ellington_Project.EllingtonDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(18, 211)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(129, 15)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Total Jacksonville sales:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(164, 211)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(101, 15)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Total Miami sales:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(293, 211)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(103, 15)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Total Tampa sales:"
        '
        'lblJacksonville
        '
        Me.lblJacksonville.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblJacksonville.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblJacksonville.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblJacksonville.Location = New System.Drawing.Point(21, 232)
        Me.lblJacksonville.Name = "lblJacksonville"
        Me.lblJacksonville.Size = New System.Drawing.Size(98, 26)
        Me.lblJacksonville.TabIndex = 4
        Me.lblJacksonville.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblMiami
        '
        Me.lblMiami.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblMiami.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblMiami.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMiami.Location = New System.Drawing.Point(167, 232)
        Me.lblMiami.Name = "lblMiami"
        Me.lblMiami.Size = New System.Drawing.Size(98, 26)
        Me.lblMiami.TabIndex = 5
        Me.lblMiami.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblTampa
        '
        Me.lblTampa.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblTampa.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTampa.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTampa.Location = New System.Drawing.Point(296, 232)
        Me.lblTampa.Name = "lblTampa"
        Me.lblTampa.Size = New System.Drawing.Size(98, 26)
        Me.lblTampa.TabIndex = 6
        Me.lblTampa.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(414, 287)
        Me.Controls.Add(Me.lblTampa)
        Me.Controls.Add(Me.lblMiami)
        Me.Controls.Add(Me.lblJacksonville)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.DataGridView1)
        Me.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MaximizeBox = False
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Ellington Company"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Sales2019BindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EllingtonDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents EllingtonDataSet As EllingtonDataSet
    Friend WithEvents Sales2019BindingSource As BindingSource
    Friend WithEvents Sales2019TableAdapter As EllingtonDataSetTableAdapters.Sales2019TableAdapter
    Friend WithEvents TableAdapterManager As EllingtonDataSetTableAdapters.TableAdapterManager
    Friend WithEvents MonthDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents JacksonvilleDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents MiamiDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents TampaDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents TotalDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents lblJacksonville As Label
    Friend WithEvents lblMiami As Label
    Friend WithEvents lblTampa As Label
End Class

﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.OscarsDataSet = New Oscars_Project.OscarsDataSet()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.YearDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ActorDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ActressDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PictureDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AnimatedDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.WinnersBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.WinnersTableAdapter = New Oscars_Project.OscarsDataSetTableAdapters.WinnersTableAdapter()
        Me.TableAdapterManager = New Oscars_Project.OscarsDataSetTableAdapters.TableAdapterManager()
        Me.btnExit = New System.Windows.Forms.Button()
        CType(Me.OscarsDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.WinnersBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'OscarsDataSet
        '
        Me.OscarsDataSet.DataSetName = "OscarsDataSet"
        Me.OscarsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.YearDataGridViewTextBoxColumn, Me.ActorDataGridViewTextBoxColumn, Me.ActressDataGridViewTextBoxColumn, Me.PictureDataGridViewTextBoxColumn, Me.AnimatedDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.WinnersBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(0, 0)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView1.Size = New System.Drawing.Size(587, 245)
        Me.DataGridView1.TabIndex = 1
        '
        'YearDataGridViewTextBoxColumn
        '
        Me.YearDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader
        Me.YearDataGridViewTextBoxColumn.DataPropertyName = "Year"
        Me.YearDataGridViewTextBoxColumn.HeaderText = "Year"
        Me.YearDataGridViewTextBoxColumn.Name = "YearDataGridViewTextBoxColumn"
        Me.YearDataGridViewTextBoxColumn.ReadOnly = True
        Me.YearDataGridViewTextBoxColumn.Width = 54
        '
        'ActorDataGridViewTextBoxColumn
        '
        Me.ActorDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.ActorDataGridViewTextBoxColumn.DataPropertyName = "Actor"
        Me.ActorDataGridViewTextBoxColumn.HeaderText = "Actor"
        Me.ActorDataGridViewTextBoxColumn.Name = "ActorDataGridViewTextBoxColumn"
        Me.ActorDataGridViewTextBoxColumn.ReadOnly = True
        Me.ActorDataGridViewTextBoxColumn.Width = 61
        '
        'ActressDataGridViewTextBoxColumn
        '
        Me.ActressDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.ActressDataGridViewTextBoxColumn.DataPropertyName = "Actress"
        Me.ActressDataGridViewTextBoxColumn.HeaderText = "Actress"
        Me.ActressDataGridViewTextBoxColumn.Name = "ActressDataGridViewTextBoxColumn"
        Me.ActressDataGridViewTextBoxColumn.ReadOnly = True
        Me.ActressDataGridViewTextBoxColumn.Width = 70
        '
        'PictureDataGridViewTextBoxColumn
        '
        Me.PictureDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.PictureDataGridViewTextBoxColumn.DataPropertyName = "Picture"
        Me.PictureDataGridViewTextBoxColumn.HeaderText = "Picture"
        Me.PictureDataGridViewTextBoxColumn.Name = "PictureDataGridViewTextBoxColumn"
        Me.PictureDataGridViewTextBoxColumn.ReadOnly = True
        Me.PictureDataGridViewTextBoxColumn.Width = 69
        '
        'AnimatedDataGridViewTextBoxColumn
        '
        Me.AnimatedDataGridViewTextBoxColumn.DataPropertyName = "Animated"
        Me.AnimatedDataGridViewTextBoxColumn.HeaderText = "Animated"
        Me.AnimatedDataGridViewTextBoxColumn.Name = "AnimatedDataGridViewTextBoxColumn"
        Me.AnimatedDataGridViewTextBoxColumn.ReadOnly = True
        '
        'WinnersBindingSource
        '
        Me.WinnersBindingSource.DataMember = "Winners"
        Me.WinnersBindingSource.DataSource = Me.OscarsDataSet
        '
        'WinnersTableAdapter
        '
        Me.WinnersTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.UpdateOrder = Oscars_Project.OscarsDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        Me.TableAdapterManager.WinnersTableAdapter = Me.WinnersTableAdapter
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(500, 255)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 0
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(587, 290)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.DataGridView1)
        Me.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MaximizeBox = False
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Oscar Winners"
        CType(Me.OscarsDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.WinnersBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents OscarsDataSet As OscarsDataSet
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents WinnersBindingSource As BindingSource
    Friend WithEvents WinnersTableAdapter As OscarsDataSetTableAdapters.WinnersTableAdapter
    Friend WithEvents TableAdapterManager As OscarsDataSetTableAdapters.TableAdapterManager
    Friend WithEvents YearDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ActorDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ActressDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents PictureDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents AnimatedDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents btnExit As Button
End Class

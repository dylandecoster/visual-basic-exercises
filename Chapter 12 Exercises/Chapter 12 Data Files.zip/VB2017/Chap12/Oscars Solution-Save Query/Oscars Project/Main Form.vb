﻿' Name:         Oscars Project
' Purpose:      Displays either all records or a record for a specific year.
' Programmer:   <your name> on <current date>

Option Explicit On
Option Strict On
Option Infer Off

Public Class frmMain
    Private Sub btnDisplay_Click(sender As Object, e As EventArgs) Handles btnDisplay.Click
        ' Displays all records or a record for a specific year.


    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'OscarsDataSet.Winners' table. You can move, or remove it, as needed.
        Me.WinnersTableAdapter.Fill(Me.OscarsDataSet.Winners)

    End Sub
End Class

﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.txtYear = New System.Windows.Forms.TextBox()
        Me.btnDisplay = New System.Windows.Forms.Button()
        Me.radYear = New System.Windows.Forms.RadioButton()
        Me.radAll = New System.Windows.Forms.RadioButton()
        Me.TblOscarsDataGridView = New System.Windows.Forms.DataGridView()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.OscarsDataSet = New Oscars_Project.OscarsDataSet()
        Me.WinnersBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.WinnersTableAdapter = New Oscars_Project.OscarsDataSetTableAdapters.WinnersTableAdapter()
        Me.TableAdapterManager = New Oscars_Project.OscarsDataSetTableAdapters.TableAdapterManager()
        Me.YearDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ActorDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ActressDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PictureDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AnimatedDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel1.SuspendLayout()
        CType(Me.TblOscarsDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.OscarsDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.WinnersBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.txtYear)
        Me.Panel1.Controls.Add(Me.btnDisplay)
        Me.Panel1.Controls.Add(Me.radYear)
        Me.Panel1.Controls.Add(Me.radAll)
        Me.Panel1.Location = New System.Drawing.Point(687, 35)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(102, 131)
        Me.Panel1.TabIndex = 1
        '
        'txtYear
        '
        Me.txtYear.Location = New System.Drawing.Point(18, 96)
        Me.txtYear.Name = "txtYear"
        Me.txtYear.Size = New System.Drawing.Size(45, 23)
        Me.txtYear.TabIndex = 3
        '
        'btnDisplay
        '
        Me.btnDisplay.Location = New System.Drawing.Point(9, 17)
        Me.btnDisplay.Name = "btnDisplay"
        Me.btnDisplay.Size = New System.Drawing.Size(75, 23)
        Me.btnDisplay.TabIndex = 0
        Me.btnDisplay.Text = "&Display"
        Me.btnDisplay.UseVisualStyleBackColor = True
        '
        'radYear
        '
        Me.radYear.AutoSize = True
        Me.radYear.Location = New System.Drawing.Point(15, 72)
        Me.radYear.Name = "radYear"
        Me.radYear.Size = New System.Drawing.Size(47, 19)
        Me.radYear.TabIndex = 2
        Me.radYear.Text = "&Year"
        Me.radYear.UseVisualStyleBackColor = True
        '
        'radAll
        '
        Me.radAll.AutoSize = True
        Me.radAll.Checked = True
        Me.radAll.Location = New System.Drawing.Point(15, 46)
        Me.radAll.Name = "radAll"
        Me.radAll.Size = New System.Drawing.Size(39, 19)
        Me.radAll.TabIndex = 1
        Me.radAll.TabStop = True
        Me.radAll.Text = "&All"
        Me.radAll.UseVisualStyleBackColor = True
        '
        'TblOscarsDataGridView
        '
        Me.TblOscarsDataGridView.AllowUserToAddRows = False
        Me.TblOscarsDataGridView.AllowUserToDeleteRows = False
        Me.TblOscarsDataGridView.AutoGenerateColumns = False
        Me.TblOscarsDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.TblOscarsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.TblOscarsDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.YearDataGridViewTextBoxColumn, Me.ActorDataGridViewTextBoxColumn, Me.ActressDataGridViewTextBoxColumn, Me.PictureDataGridViewTextBoxColumn, Me.AnimatedDataGridViewTextBoxColumn})
        Me.TblOscarsDataGridView.DataSource = Me.WinnersBindingSource
        Me.TblOscarsDataGridView.Location = New System.Drawing.Point(12, 35)
        Me.TblOscarsDataGridView.Name = "TblOscarsDataGridView"
        Me.TblOscarsDataGridView.ReadOnly = True
        Me.TblOscarsDataGridView.RowHeadersVisible = False
        Me.TblOscarsDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.TblOscarsDataGridView.Size = New System.Drawing.Size(663, 245)
        Me.TblOscarsDataGridView.StandardTab = True
        Me.TblOscarsDataGridView.TabIndex = 0
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(687, 253)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 27)
        Me.btnExit.TabIndex = 2
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'OscarsDataSet
        '
        Me.OscarsDataSet.DataSetName = "OscarsDataSet"
        Me.OscarsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'WinnersBindingSource
        '
        Me.WinnersBindingSource.DataMember = "Winners"
        Me.WinnersBindingSource.DataSource = Me.OscarsDataSet
        '
        'WinnersTableAdapter
        '
        Me.WinnersTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.UpdateOrder = Oscars_Project.OscarsDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        Me.TableAdapterManager.WinnersTableAdapter = Me.WinnersTableAdapter
        '
        'YearDataGridViewTextBoxColumn
        '
        Me.YearDataGridViewTextBoxColumn.DataPropertyName = "Year"
        Me.YearDataGridViewTextBoxColumn.HeaderText = "Year"
        Me.YearDataGridViewTextBoxColumn.Name = "YearDataGridViewTextBoxColumn"
        Me.YearDataGridViewTextBoxColumn.ReadOnly = True
        '
        'ActorDataGridViewTextBoxColumn
        '
        Me.ActorDataGridViewTextBoxColumn.DataPropertyName = "Actor"
        Me.ActorDataGridViewTextBoxColumn.HeaderText = "Actor"
        Me.ActorDataGridViewTextBoxColumn.Name = "ActorDataGridViewTextBoxColumn"
        Me.ActorDataGridViewTextBoxColumn.ReadOnly = True
        '
        'ActressDataGridViewTextBoxColumn
        '
        Me.ActressDataGridViewTextBoxColumn.DataPropertyName = "Actress"
        Me.ActressDataGridViewTextBoxColumn.HeaderText = "Actress"
        Me.ActressDataGridViewTextBoxColumn.Name = "ActressDataGridViewTextBoxColumn"
        Me.ActressDataGridViewTextBoxColumn.ReadOnly = True
        '
        'PictureDataGridViewTextBoxColumn
        '
        Me.PictureDataGridViewTextBoxColumn.DataPropertyName = "Picture"
        Me.PictureDataGridViewTextBoxColumn.HeaderText = "Picture"
        Me.PictureDataGridViewTextBoxColumn.Name = "PictureDataGridViewTextBoxColumn"
        Me.PictureDataGridViewTextBoxColumn.ReadOnly = True
        '
        'AnimatedDataGridViewTextBoxColumn
        '
        Me.AnimatedDataGridViewTextBoxColumn.DataPropertyName = "Animated"
        Me.AnimatedDataGridViewTextBoxColumn.HeaderText = "Animated"
        Me.AnimatedDataGridViewTextBoxColumn.Name = "AnimatedDataGridViewTextBoxColumn"
        Me.AnimatedDataGridViewTextBoxColumn.ReadOnly = True
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(809, 305)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.TblOscarsDataGridView)
        Me.Controls.Add(Me.btnExit)
        Me.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MaximizeBox = False
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Oscar Winners"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.TblOscarsDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.OscarsDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.WinnersBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents txtYear As TextBox
    Friend WithEvents btnDisplay As Button
    Friend WithEvents radYear As RadioButton
    Friend WithEvents radAll As RadioButton
    Friend WithEvents TblOscarsDataGridView As DataGridView
    Friend WithEvents btnExit As Button
    Friend WithEvents OscarsDataSet As OscarsDataSet
    Friend WithEvents WinnersBindingSource As BindingSource
    Friend WithEvents WinnersTableAdapter As OscarsDataSetTableAdapters.WinnersTableAdapter
    Friend WithEvents TableAdapterManager As OscarsDataSetTableAdapters.TableAdapterManager
    Friend WithEvents YearDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ActorDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ActressDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents PictureDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents AnimatedDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
End Class

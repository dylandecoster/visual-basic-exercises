﻿Partial Class AdaleneDataSet
End Class

Namespace AdaleneDataSetTableAdapters

    Partial Public Class StoresTableAdapter
    End Class
End Namespace

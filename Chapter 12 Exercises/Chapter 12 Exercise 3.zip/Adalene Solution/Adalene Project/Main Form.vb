﻿' Name:         Adalene Project
' Purpose:      Select and view records.
' Programmer:   Dylan DeCoster on 11/11/19

Option Explicit On
Option Strict On
Option Infer Off

Public Class frmMain
    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'AdaleneDataSet.Stores' table. You can move, or remove it, as needed.
        Me.StoresTableAdapter.Fill(Me.AdaleneDataSet.Stores)

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnDisplay_Click(sender As Object, e As EventArgs) Handles btnDisplay.Click
        If Me.radAll.Checked Then
            StoresTableAdapter.Fill(AdaleneDataSet.Stores)
        ElseIf Me.radCompany.Checked Then
            StoresTableAdapter.FillBy(AdaleneDataSet.Stores)
        ElseIf Me.radFranchisee.Checked Then
            StoresTableAdapter.FillBy1(AdaleneDataSet.Stores)
        End If
    End Sub
End Class

﻿' Name:         Jacobson Solution
' Purpose:      Calculate and display the sales tax and total due.
' Programmer:   Dylan DeCoster on 10/14/19

Public Class frmMain
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        Dim sales, tax As Double
        sales = Val(Me.txtSales.Text)
        tax = sales * 0.05

        Me.lblTax.Text = Format(tax, "0.00")
        Me.lblTotal.Text = "$" + Format(tax + sales, "0.00")
    End Sub
End Class

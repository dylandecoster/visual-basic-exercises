﻿' Name:         Orders Project
' Purpose:      Calculate and display the total numbered ordered.
' Programmer:   Dylan DeCoster on 10/14/19

Option Explicit On
Option Strict On
Option Infer Off

Public Class frmMain
    Dim total As Double = 0

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        'Adds the users input to total
        total += Val(Me.txtNumOrdered.Text)
        'Converts it to a string and stores it in the label
        Me.lblTotal.Text = total.ToString()
    End Sub

    Private Sub btnSubtract_Click(sender As Object, e As EventArgs) Handles btnSubtract.Click
        'Subtracts the users input from total
        total -= Val(Me.txtNumOrdered.Text)
        'Converts it to a string and stores it in the label
        Me.lblTotal.Text = total.ToString()
    End Sub
End Class

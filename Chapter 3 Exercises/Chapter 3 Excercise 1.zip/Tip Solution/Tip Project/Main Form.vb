﻿' Name:         Tip Project
' Purpose:      Calculate and display a server's tip.
' Programmer:   Dylan DeCoster on 10/9/19


Public Class frmMain
    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        ' Calculates and displays a server's tip.

        ' Declare Decimal variables.
        Dim bill, tipPercent, tip As Double
        ' Convert txtBill.Text and txtPercentage.Text to numbers.
        bill = Val(Me.txtBill.Text)
        tipPercent = Val(Me.txtPercentage.Text)
        ' Calculate the tip.
        tip = bill * (tipPercent / 100)
        ' Display the tip with a dollar sign and two decimal places.
        Me.lblTip.Text = "$" + Format(tip, "0.00")
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()

    End Sub

End Class

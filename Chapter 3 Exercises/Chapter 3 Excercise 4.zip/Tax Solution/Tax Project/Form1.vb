﻿'Project: Tax Project
'Purpose: Calculate tax of property
'Name: Dylan DeCoster on 10/14/19

Public Class frmMain
    'Makes a new constant for the tax
    Const tax As Double = 0.0135
    'Makes a new variable
    Dim value As Double

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()

    End Sub

    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        'Gets the users input
        value = Val(Me.txtVal.Text)
        'Formats the currency
        Me.lblTax.Text = FormatCurrency(value * tax, TriState.True)
    End Sub
End Class

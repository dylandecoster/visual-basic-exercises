﻿'Name: MoonBucks
'Purpose: calculate some stuff
'Programmer: Dylan DeCoster on 10/14/19

Public Class frmMain
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()

    End Sub

    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        Dim current, increase As Double
        'Gets the users input
        current = Val(Me.txtCurrent.Text)
        'Gets 10 percent of current
        increase = Format(current * 0.1, "0.00")

        'Sets the label to the increase amount
        Me.lblIncrease.Text = increase
        'Sets the label to the increase + the current amount
        Me.lblProjected.Text = Format(increase + current, "0.00")
    End Sub
End Class

﻿'Project: Text Message Symbols
'Purpose: Show each meaning of the pictures
'Name: Dylan DeCoster on 10/8/19

Public Class frmMain
    Private Sub picBFF_Click(sender As Object, e As EventArgs) Handles picBFF.Click
        Me.lblMeaning.Text = "Best Friends Forever"
    End Sub

    Private Sub picBRB_Click(sender As Object, e As EventArgs) Handles picBRB.Click
        Me.lblMeaning.Text = "Be Right Back"
    End Sub

    Private Sub picIDK_Click(sender As Object, e As EventArgs) Handles picIDK.Click
        Me.lblMeaning.Text = "I Don't Know"
    End Sub

    Private Sub picLOL_Click(sender As Object, e As EventArgs) Handles picLOL.Click
        Me.lblMeaning.Text = "Laugh Out Loud"
    End Sub

    Private Sub picSRY_Click(sender As Object, e As EventArgs) Handles picSRY.Click
        Me.lblMeaning.Text = "Sorry"
    End Sub

    Private Sub picXO_Click(sender As Object, e As EventArgs) Handles picXO.Click
        Me.lblMeaning.Text = "Hugs and Kisses"
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()

    End Sub
End Class

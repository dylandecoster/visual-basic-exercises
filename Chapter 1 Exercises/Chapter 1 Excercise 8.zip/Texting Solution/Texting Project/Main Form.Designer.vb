﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblMeaning = New System.Windows.Forms.Label()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.picBFF = New System.Windows.Forms.PictureBox()
        Me.picBRB = New System.Windows.Forms.PictureBox()
        Me.picIDK = New System.Windows.Forms.PictureBox()
        Me.picLOL = New System.Windows.Forms.PictureBox()
        Me.picSRY = New System.Windows.Forms.PictureBox()
        Me.picXO = New System.Windows.Forms.PictureBox()
        CType(Me.picBFF, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBRB, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picIDK, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picLOL, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picSRY, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picXO, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblMeaning
        '
        Me.lblMeaning.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblMeaning.Font = New System.Drawing.Font("Segoe UI", 18.0!)
        Me.lblMeaning.Location = New System.Drawing.Point(12, 88)
        Me.lblMeaning.Name = "lblMeaning"
        Me.lblMeaning.Size = New System.Drawing.Size(331, 71)
        Me.lblMeaning.TabIndex = 0
        Me.lblMeaning.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(349, 136)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 1
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'picBFF
        '
        Me.picBFF.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.picBFF.Image = Global.Texting_Project.My.Resources.Resources.BFF
        Me.picBFF.Location = New System.Drawing.Point(14, 24)
        Me.picBFF.Name = "picBFF"
        Me.picBFF.Size = New System.Drawing.Size(50, 35)
        Me.picBFF.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picBFF.TabIndex = 2
        Me.picBFF.TabStop = False
        '
        'picBRB
        '
        Me.picBRB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.picBRB.Image = Global.Texting_Project.My.Resources.Resources.BRB
        Me.picBRB.Location = New System.Drawing.Point(70, 24)
        Me.picBRB.Name = "picBRB"
        Me.picBRB.Size = New System.Drawing.Size(50, 35)
        Me.picBRB.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picBRB.TabIndex = 3
        Me.picBRB.TabStop = False
        '
        'picIDK
        '
        Me.picIDK.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.picIDK.Image = Global.Texting_Project.My.Resources.Resources.IDK
        Me.picIDK.Location = New System.Drawing.Point(126, 24)
        Me.picIDK.Name = "picIDK"
        Me.picIDK.Size = New System.Drawing.Size(50, 35)
        Me.picIDK.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picIDK.TabIndex = 4
        Me.picIDK.TabStop = False
        '
        'picLOL
        '
        Me.picLOL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.picLOL.Image = Global.Texting_Project.My.Resources.Resources.LOL
        Me.picLOL.Location = New System.Drawing.Point(182, 24)
        Me.picLOL.Name = "picLOL"
        Me.picLOL.Size = New System.Drawing.Size(50, 35)
        Me.picLOL.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picLOL.TabIndex = 5
        Me.picLOL.TabStop = False
        '
        'picSRY
        '
        Me.picSRY.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.picSRY.Image = Global.Texting_Project.My.Resources.Resources.SRY
        Me.picSRY.Location = New System.Drawing.Point(238, 24)
        Me.picSRY.Name = "picSRY"
        Me.picSRY.Size = New System.Drawing.Size(50, 35)
        Me.picSRY.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picSRY.TabIndex = 6
        Me.picSRY.TabStop = False
        '
        'picXO
        '
        Me.picXO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.picXO.Image = Global.Texting_Project.My.Resources.Resources.XO
        Me.picXO.Location = New System.Drawing.Point(294, 24)
        Me.picXO.Name = "picXO"
        Me.picXO.Size = New System.Drawing.Size(50, 35)
        Me.picXO.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picXO.TabIndex = 7
        Me.picXO.TabStop = False
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(437, 173)
        Me.Controls.Add(Me.picXO)
        Me.Controls.Add(Me.picSRY)
        Me.Controls.Add(Me.picLOL)
        Me.Controls.Add(Me.picIDK)
        Me.Controls.Add(Me.picBRB)
        Me.Controls.Add(Me.picBFF)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.lblMeaning)
        Me.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MaximizeBox = False
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Text Message Symbols"
        CType(Me.picBFF, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBRB, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picIDK, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picLOL, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picSRY, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picXO, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents lblMeaning As Label
    Friend WithEvents btnExit As Button
    Friend WithEvents picBFF As PictureBox
    Friend WithEvents picBRB As PictureBox
    Friend WithEvents picIDK As PictureBox
    Friend WithEvents picLOL As PictureBox
    Friend WithEvents picSRY As PictureBox
    Friend WithEvents picXO As PictureBox
End Class

﻿'Name: Dylan DeCoster'
'Date: 10/7/19'
'Description: Show the size chart on click'

Public Class frmMain
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnChart_Click(sender As Object, e As EventArgs) Handles btnChart.Click
        Me.picChart.Show()
    End Sub
End Class

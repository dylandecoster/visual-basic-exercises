﻿'Project: OnYourOwn
'Purpose: Shrek and Donkey
'Name: Dylan DeCoster on 10/8/19

Public Class Form1
    Private Sub pic1_Click(sender As Object, e As EventArgs) Handles pic1.Click
        Me.lblText.Text = "Its shrek."
    End Sub

    Private Sub pic2_Click(sender As Object, e As EventArgs) Handles pic2.Click
        Me.lblText.Text = "Its donkey."
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()

    End Sub
End Class

﻿'Name: Dylan DeCoster'
'Date: 10/7/19'
'Description: Show the size chart on click and change the jacket colors'

Public Class frmMain
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnChart_Click(sender As Object, e As EventArgs) Handles btnChart.Click
        Me.picChart.Show()
    End Sub

    Private Sub btnBlack_Click(sender As Object, e As EventArgs) Handles btnBlack.Click
        ' Display the black jacket.

        picJacket.Image = My.Resources.BlackJacket
    End Sub

    Private Sub btnBlue_Click(sender As Object, e As EventArgs) Handles btnBlue.Click
        ' Display the black jacket.

        picJacket.Image = My.Resources.BlueJacket
    End Sub

    Private Sub btnBrown_Click(sender As Object, e As EventArgs) Handles btnBrown.Click
        ' Display the black jacket.

        picJacket.Image = My.Resources.BrownJacket
    End Sub

    Private Sub btnRed_Click(sender As Object, e As EventArgs) Handles btnRed.Click
        ' Display the black jacket.

        picJacket.Image = My.Resources.RedJacket
    End Sub
End Class

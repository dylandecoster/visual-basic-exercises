﻿' Name:         Emoji Project
' Purpose:      Display a message corresponding to an emoji.
' Programmer:   Dylan DeCoster on 10/8/19

Public Class frmMain
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub picCrying_Click(sender As Object, e As EventArgs) Handles picCrying.Click
        Me.lblMessage.Text = "I am crying."
    End Sub

    Private Sub picHappy_Click(sender As Object, e As EventArgs) Handles picHappy.Click
        Me.lblMessage.Text = "I am happy."
    End Sub

    Private Sub picLove_Click(sender As Object, e As EventArgs) Handles picLove.Click
        Me.lblMessage.Text = "I am in love."
    End Sub

    Private Sub picSad_Click(sender As Object, e As EventArgs) Handles picSad.Click
        Me.lblMessage.Text = "I am sad."
    End Sub

    Private Sub picTired_Click(sender As Object, e As EventArgs) Handles picTired.Click
        Me.lblMessage.Text = "I am tired."
    End Sub
End Class

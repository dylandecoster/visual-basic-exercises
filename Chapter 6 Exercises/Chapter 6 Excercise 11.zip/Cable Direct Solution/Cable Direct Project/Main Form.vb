﻿Imports System.ComponentModel
'Name:          Cable Direct
'Purpose:       Calculate cost of channels
'Programmer:    Dylan DeCoster on 10/22/19

Public Class frmMain
    'Checks which type is selected and formats accordingly
    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        If (Me.rbBusiness.Checked) Then
            Me.lblTotal.Text = "$" + Business().ToString("N2")
        ElseIf (Me.rbResidential.Checked) Then
            Me.lblTotal.Text = "$" + Residential().ToString("N2")
        End If
    End Sub

    'Calculates the business type
    Private Function Business() As Double
        Dim connections As Integer = Me.lbConnections.SelectedItem
        Dim premium As Integer = Me.lbPremium.SelectedItem
        Dim total As Double = 96.5

        'Cost 4 extra for each channel above 10
        If (connections > 10) Then
            total += (connections - 10) * 4
        End If

        total += 50 * premium

        Return total
    End Function

    'Calculates the residential type
    Private Function Residential() As Double
        Dim premium As Integer = Me.lbPremium.SelectedItem
        Dim total As Double = 34.5

        total += premium * 5

        Return total
    End Function

    'Exits the application
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    'Inputs all the numbers into the list box
    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        For intPremium As Integer = 0 To 20
            Me.lbPremium.Items.Add(intPremium)
        Next intPremium
        For intConnections As Integer = 0 To 100
            Me.lbConnections.Items.Add(intConnections)
        Next intConnections

        'Selects the first item of each list box
        Me.lbPremium.SelectedIndex = 0
        Me.lbConnections.SelectedIndex = 0
    End Sub

    'Clears the text
    Private Sub ClearText(sender As Object, e As EventArgs) _
        Handles rbBusiness.CheckedChanged, rbResidential.CheckedChanged,
        lbPremium.SelectedIndexChanged, lbConnections.SelectedIndexChanged

        Me.lblTotal.Text = Nothing
    End Sub

    'Closing message box
    Private Sub frmMain_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
        Dim box As DialogResult
        box = MessageBox.Show("Are you sure you want to exit?", "Cable Direct", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation)

        If (box = DialogResult.No) Then
            e.Cancel = True
        End If
    End Sub
End Class

﻿'Name:          Translator
'Purpose:       Translate different relatives
'Programmer:    Dylan DeCoster on 10/22/19

Public Class frmMain
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnTranslate.Click
        'Translates all the crap
        Select Case True
            'Checks for mother in all languages
            Case Me.rbMother.Checked And Me.cboLang.SelectedIndex = 0
                Me.lblAnswer.Text = "mère"
            Case Me.rbMother.Checked And Me.cboLang.SelectedIndex = 1
                Me.lblAnswer.Text = "madre"
            Case Me.rbMother.Checked And Me.cboLang.SelectedIndex = 2
                Me.lblAnswer.Text = "madre"
            'Checks for father in all languages
            Case Me.rbFather.Checked And Me.cboLang.SelectedIndex = 0
                Me.lblAnswer.Text = "père"
            Case Me.rbFather.Checked And Me.cboLang.SelectedIndex = 1
                Me.lblAnswer.Text = "padre"
            Case Me.rbFather.Checked And Me.cboLang.SelectedIndex = 2
                Me.lblAnswer.Text = "padre"
            'Checks for sister in all languages
            Case Me.rbSister.Checked And Me.cboLang.SelectedIndex = 0
                Me.lblAnswer.Text = "sœur"
            Case Me.rbSister.Checked And Me.cboLang.SelectedIndex = 1
                Me.lblAnswer.Text = "sorella"
            Case Me.rbSister.Checked And Me.cboLang.SelectedIndex = 2
                Me.lblAnswer.Text = "hermana"
            'Checks for brother in all languages
            Case Me.rbBrother.Checked And Me.cboLang.SelectedIndex = 0
                Me.lblAnswer.Text = "frère"
            Case Me.rbBrother.Checked And Me.cboLang.SelectedIndex = 1
                Me.lblAnswer.Text = "fratello"
            Case Me.rbBrother.Checked And Me.cboLang.SelectedIndex = 2
                Me.lblAnswer.Text = "hermano"
        End Select
    End Sub

    'Closes application
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    'Auto selects first item in combo box
    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.cboLang.SelectedIndex = 0
    End Sub

    'Clears the text
    Private Sub ClearText(sender As Object, e As EventArgs) _
        Handles rbSister.CheckedChanged, rbBrother.CheckedChanged, rbMother.CheckedChanged, rbFather.CheckedChanged,
        cboLang.SelectedIndexChanged

        Me.lblAnswer.Text = Nothing
    End Sub
End Class

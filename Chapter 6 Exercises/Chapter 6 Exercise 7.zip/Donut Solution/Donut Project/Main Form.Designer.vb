﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.rbFilled = New System.Windows.Forms.RadioButton()
        Me.rbChocolate = New System.Windows.Forms.RadioButton()
        Me.rbSugar = New System.Windows.Forms.RadioButton()
        Me.rbGlazed = New System.Windows.Forms.RadioButton()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.rbCapp = New System.Windows.Forms.RadioButton()
        Me.rbReg = New System.Windows.Forms.RadioButton()
        Me.rbNone = New System.Windows.Forms.RadioButton()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.lblDue = New System.Windows.Forms.Label()
        Me.lblTax = New System.Windows.Forms.Label()
        Me.lblSub = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnCalc = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Arial Narrow", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(9, 14)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(359, 23)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Our doughnuts and coffee are the best in town!"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rbFilled)
        Me.GroupBox1.Controls.Add(Me.rbChocolate)
        Me.GroupBox1.Controls.Add(Me.rbSugar)
        Me.GroupBox1.Controls.Add(Me.rbGlazed)
        Me.GroupBox1.Location = New System.Drawing.Point(42, 40)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(155, 172)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Doughnut choices"
        '
        'rbFilled
        '
        Me.rbFilled.AutoSize = True
        Me.rbFilled.Location = New System.Drawing.Point(7, 130)
        Me.rbFilled.Name = "rbFilled"
        Me.rbFilled.Size = New System.Drawing.Size(85, 17)
        Me.rbFilled.TabIndex = 3
        Me.rbFilled.TabStop = True
        Me.rbFilled.Text = "&Filled ($1.50)"
        Me.rbFilled.UseVisualStyleBackColor = True
        '
        'rbChocolate
        '
        Me.rbChocolate.AutoSize = True
        Me.rbChocolate.Location = New System.Drawing.Point(6, 92)
        Me.rbChocolate.Name = "rbChocolate"
        Me.rbChocolate.Size = New System.Drawing.Size(103, 17)
        Me.rbChocolate.TabIndex = 2
        Me.rbChocolate.TabStop = True
        Me.rbChocolate.Text = "C&hocolate (1.25)"
        Me.rbChocolate.UseVisualStyleBackColor = True
        '
        'rbSugar
        '
        Me.rbSugar.AutoSize = True
        Me.rbSugar.Location = New System.Drawing.Point(7, 54)
        Me.rbSugar.Name = "rbSugar"
        Me.rbSugar.Size = New System.Drawing.Size(89, 17)
        Me.rbSugar.TabIndex = 1
        Me.rbSugar.TabStop = True
        Me.rbSugar.Text = "&Sugar ($1.05)"
        Me.rbSugar.UseVisualStyleBackColor = True
        '
        'rbGlazed
        '
        Me.rbGlazed.AutoSize = True
        Me.rbGlazed.Location = New System.Drawing.Point(7, 20)
        Me.rbGlazed.Name = "rbGlazed"
        Me.rbGlazed.Size = New System.Drawing.Size(94, 17)
        Me.rbGlazed.TabIndex = 0
        Me.rbGlazed.TabStop = True
        Me.rbGlazed.Text = "&Glazed ($1.05)"
        Me.rbGlazed.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.rbCapp)
        Me.GroupBox2.Controls.Add(Me.rbReg)
        Me.GroupBox2.Controls.Add(Me.rbNone)
        Me.GroupBox2.Location = New System.Drawing.Point(41, 218)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(156, 100)
        Me.GroupBox2.TabIndex = 2
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Coffee choices"
        '
        'rbCapp
        '
        Me.rbCapp.AutoSize = True
        Me.rbCapp.Location = New System.Drawing.Point(8, 65)
        Me.rbCapp.Name = "rbCapp"
        Me.rbCapp.Size = New System.Drawing.Size(118, 17)
        Me.rbCapp.TabIndex = 6
        Me.rbCapp.TabStop = True
        Me.rbCapp.Text = "Ca&ppuccino ($2.75)"
        Me.rbCapp.UseVisualStyleBackColor = True
        '
        'rbReg
        '
        Me.rbReg.AutoSize = True
        Me.rbReg.Location = New System.Drawing.Point(8, 42)
        Me.rbReg.Name = "rbReg"
        Me.rbReg.Size = New System.Drawing.Size(98, 17)
        Me.rbReg.TabIndex = 5
        Me.rbReg.TabStop = True
        Me.rbReg.Text = "&Regular ($1.50)"
        Me.rbReg.UseVisualStyleBackColor = True
        '
        'rbNone
        '
        Me.rbNone.AutoSize = True
        Me.rbNone.Location = New System.Drawing.Point(8, 19)
        Me.rbNone.Name = "rbNone"
        Me.rbNone.Size = New System.Drawing.Size(51, 17)
        Me.rbNone.TabIndex = 4
        Me.rbNone.TabStop = True
        Me.rbNone.Text = "&None"
        Me.rbNone.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.lblDue)
        Me.GroupBox3.Controls.Add(Me.lblTax)
        Me.GroupBox3.Controls.Add(Me.lblSub)
        Me.GroupBox3.Controls.Add(Me.Label4)
        Me.GroupBox3.Controls.Add(Me.Label3)
        Me.GroupBox3.Controls.Add(Me.Label2)
        Me.GroupBox3.Location = New System.Drawing.Point(203, 40)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(134, 172)
        Me.GroupBox3.TabIndex = 3
        Me.GroupBox3.TabStop = False
        '
        'lblDue
        '
        Me.lblDue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblDue.Location = New System.Drawing.Point(64, 111)
        Me.lblDue.Name = "lblDue"
        Me.lblDue.Size = New System.Drawing.Size(50, 15)
        Me.lblDue.TabIndex = 5
        Me.lblDue.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblTax
        '
        Me.lblTax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTax.Location = New System.Drawing.Point(63, 73)
        Me.lblTax.Name = "lblTax"
        Me.lblTax.Size = New System.Drawing.Size(50, 15)
        Me.lblTax.TabIndex = 4
        Me.lblTax.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblSub
        '
        Me.lblSub.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSub.Location = New System.Drawing.Point(64, 34)
        Me.lblSub.Name = "lblSub"
        Me.lblSub.Size = New System.Drawing.Size(50, 15)
        Me.lblSub.TabIndex = 3
        Me.lblSub.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(7, 111)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(58, 13)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "Total due: "
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(6, 73)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(56, 13)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "Sales tax: "
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(6, 34)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(52, 13)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Subtotal: "
        '
        'btnCalc
        '
        Me.btnCalc.Location = New System.Drawing.Point(262, 231)
        Me.btnCalc.Name = "btnCalc"
        Me.btnCalc.Size = New System.Drawing.Size(75, 23)
        Me.btnCalc.TabIndex = 4
        Me.btnCalc.Text = "&Calculate"
        Me.btnCalc.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(262, 283)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 5
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(262, 257)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 23)
        Me.btnClear.TabIndex = 6
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(380, 332)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnCalc)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmMain"
        Me.Text = "Donut Shoppe"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents rbFilled As RadioButton
    Friend WithEvents rbChocolate As RadioButton
    Friend WithEvents rbSugar As RadioButton
    Friend WithEvents rbGlazed As RadioButton
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents rbCapp As RadioButton
    Friend WithEvents rbReg As RadioButton
    Friend WithEvents rbNone As RadioButton
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents lblDue As Label
    Friend WithEvents lblTax As Label
    Friend WithEvents lblSub As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents btnCalc As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents btnClear As Button
End Class

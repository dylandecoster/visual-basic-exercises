﻿'Name:          Donut Shoppe
'Purpose:       Calculate cost of donut toppings
'Programmer:    Dylan DeCoster on 10/17/19

Public Class frmMain
    Dim total As Double

    'Calls everything on click
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        'Gets the subtotal
        Subtotal()
        'Gets the sales tax and formats it
        Me.lblTax.Text = "$" + SalesTax(total).ToString("N2")
        'Adds the sales tax and the subtotal and formats it
        Me.lblDue.Text = "$" + (total + SalesTax(total)).ToString("N2")
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()

    End Sub

    'Clears all the labels
    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        Me.lblTax.Text = Nothing
        Me.lblSub.Text = Nothing
        Me.lblDue.Text = Nothing
    End Sub

    'Gets the subtotal
    Private Sub Subtotal()
        'Checks and adds the cost of choices
        Select Case True
            Case Me.rbGlazed.Checked OrElse Me.rbSugar.Checked
                total = 1.05
            Case Me.rbChocolate.Checked
                total = 1.25
            Case Me.rbFilled.Checked
                total = 1.5
        End Select

        'Checks and adds the cost of secondary choices
        Select Case True
            Case Me.rbReg.Checked
                total += 1.5
            Case Me.rbCapp.Checked
                total += 2.75
        End Select

        'Gets the total
        Me.lblSub.Text = "$" + total.ToString("N2")
    End Sub

    'Calculates the sales tax
    Private Function SalesTax(ByVal subtotal As Double) As Double
        Dim tax As Double = subtotal
        tax *= 0.06

        'Returns the sales tax
        Return tax
    End Function
End Class

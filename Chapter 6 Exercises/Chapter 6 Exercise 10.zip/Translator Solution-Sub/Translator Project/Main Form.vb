﻿'Name:          Translator
'Purpose:       Translate different relatives
'Programmer:    Dylan DeCoster on 10/22/19

Public Class frmMain
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnTranslate.Click
        Select Case True
            Case Me.cboLang.SelectedIndex = 0
                French()
            Case Me.cboLang.SelectedIndex = 1
                Italian()
            Case Me.cboLang.SelectedIndex = 2
                Spanish()
        End Select
    End Sub
    'Gets the translations in French
    Private Sub French()
        Select Case True
            Case Me.rbMother.Checked
                Me.lblAnswer.Text = "mère"
            Case Me.rbFather.Checked
                Me.lblAnswer.Text = "père"
            Case Me.rbSister.Checked
                Me.lblAnswer.Text = "sœur"
            Case Me.rbBrother.Checked
                Me.lblAnswer.Text = "frère"
        End Select
    End Sub
    'Gets the translations in Italian
    Private Sub Italian()
        Select Case True
            Case Me.rbMother.Checked And Me.cboLang.SelectedIndex = 1
                Me.lblAnswer.Text = "madre"
            Case Me.rbFather.Checked And Me.cboLang.SelectedIndex = 1
                Me.lblAnswer.Text = "padre"
            Case Me.rbSister.Checked And Me.cboLang.SelectedIndex = 1
                Me.lblAnswer.Text = "sorella"
            Case Me.rbBrother.Checked And Me.cboLang.SelectedIndex = 1
                Me.lblAnswer.Text = "fratello"
        End Select
    End Sub
    'Gets the translations in Spanish
    Private Sub Spanish()
        Select Case True
            Case Me.rbMother.Checked And Me.cboLang.SelectedIndex = 2
                Me.lblAnswer.Text = "madre"
            Case Me.rbFather.Checked And Me.cboLang.SelectedIndex = 2
                Me.lblAnswer.Text = "padre"
            Case Me.rbSister.Checked And Me.cboLang.SelectedIndex = 2
                Me.lblAnswer.Text = "hermana"
            Case Me.rbBrother.Checked And Me.cboLang.SelectedIndex = 2
                Me.lblAnswer.Text = "hermano"
        End Select
    End Sub

    'Closes application
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    'Auto selects first item in combo box
    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.cboLang.SelectedIndex = 0
    End Sub

    'Clears the text
    Private Sub ClearText(sender As Object, e As EventArgs) _
        Handles rbSister.CheckedChanged, rbBrother.CheckedChanged, rbMother.CheckedChanged, rbFather.CheckedChanged,
        cboLang.SelectedIndexChanged

        Me.lblAnswer.Text = Nothing
    End Sub
End Class

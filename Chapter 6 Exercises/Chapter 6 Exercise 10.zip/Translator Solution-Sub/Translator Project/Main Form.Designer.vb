﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cboLang = New System.Windows.Forms.ComboBox()
        Me.lblAnswer = New System.Windows.Forms.Label()
        Me.btnTranslate = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.rbMother = New System.Windows.Forms.RadioButton()
        Me.rbFather = New System.Windows.Forms.RadioButton()
        Me.rbSister = New System.Windows.Forms.RadioButton()
        Me.rbBrother = New System.Windows.Forms.RadioButton()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rbBrother)
        Me.GroupBox1.Controls.Add(Me.rbSister)
        Me.GroupBox1.Controls.Add(Me.rbFather)
        Me.GroupBox1.Controls.Add(Me.rbMother)
        Me.GroupBox1.Location = New System.Drawing.Point(13, 13)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(116, 122)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "English"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(144, 13)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(69, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "T&ranslate to: "
        '
        'cboLang
        '
        Me.cboLang.BackColor = System.Drawing.SystemColors.Window
        Me.cboLang.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboLang.FormattingEnabled = True
        Me.cboLang.Items.AddRange(New Object() {"French", "Italian", "Spanish"})
        Me.cboLang.Location = New System.Drawing.Point(147, 30)
        Me.cboLang.Name = "cboLang"
        Me.cboLang.Size = New System.Drawing.Size(121, 21)
        Me.cboLang.TabIndex = 2
        '
        'lblAnswer
        '
        Me.lblAnswer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblAnswer.Location = New System.Drawing.Point(147, 69)
        Me.lblAnswer.Name = "lblAnswer"
        Me.lblAnswer.Size = New System.Drawing.Size(121, 64)
        Me.lblAnswer.TabIndex = 3
        Me.lblAnswer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnTranslate
        '
        Me.btnTranslate.Location = New System.Drawing.Point(287, 28)
        Me.btnTranslate.Name = "btnTranslate"
        Me.btnTranslate.Size = New System.Drawing.Size(75, 23)
        Me.btnTranslate.TabIndex = 4
        Me.btnTranslate.Text = "&Translate"
        Me.btnTranslate.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(287, 58)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 5
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'rbMother
        '
        Me.rbMother.AutoSize = True
        Me.rbMother.Location = New System.Drawing.Point(12, 21)
        Me.rbMother.Name = "rbMother"
        Me.rbMother.Size = New System.Drawing.Size(58, 17)
        Me.rbMother.TabIndex = 0
        Me.rbMother.TabStop = True
        Me.rbMother.Text = "&Mother"
        Me.rbMother.UseVisualStyleBackColor = True
        '
        'rbFather
        '
        Me.rbFather.AutoSize = True
        Me.rbFather.Location = New System.Drawing.Point(13, 45)
        Me.rbFather.Name = "rbFather"
        Me.rbFather.Size = New System.Drawing.Size(55, 17)
        Me.rbFather.TabIndex = 1
        Me.rbFather.TabStop = True
        Me.rbFather.Text = "&Father"
        Me.rbFather.UseVisualStyleBackColor = True
        '
        'rbSister
        '
        Me.rbSister.AutoSize = True
        Me.rbSister.Location = New System.Drawing.Point(13, 69)
        Me.rbSister.Name = "rbSister"
        Me.rbSister.Size = New System.Drawing.Size(51, 17)
        Me.rbSister.TabIndex = 2
        Me.rbSister.TabStop = True
        Me.rbSister.Text = "&Sister"
        Me.rbSister.UseVisualStyleBackColor = True
        '
        'rbBrother
        '
        Me.rbBrother.AutoSize = True
        Me.rbBrother.Location = New System.Drawing.Point(13, 93)
        Me.rbBrother.Name = "rbBrother"
        Me.rbBrother.Size = New System.Drawing.Size(59, 17)
        Me.rbBrother.TabIndex = 3
        Me.rbBrother.TabStop = True
        Me.rbBrother.Text = "&Brother"
        Me.rbBrother.UseVisualStyleBackColor = True
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(391, 146)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnTranslate)
        Me.Controls.Add(Me.lblAnswer)
        Me.Controls.Add(Me.cboLang)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "frmMain"
        Me.Text = "Translator"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents rbBrother As RadioButton
    Friend WithEvents rbSister As RadioButton
    Friend WithEvents rbFather As RadioButton
    Friend WithEvents rbMother As RadioButton
    Friend WithEvents Label1 As Label
    Friend WithEvents cboLang As ComboBox
    Friend WithEvents lblAnswer As Label
    Friend WithEvents btnTranslate As Button
    Friend WithEvents btnExit As Button
End Class

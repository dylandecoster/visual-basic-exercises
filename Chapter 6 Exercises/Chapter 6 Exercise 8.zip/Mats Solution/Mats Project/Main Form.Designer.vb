﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.chkFold = New System.Windows.Forms.CheckBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblPrice = New System.Windows.Forms.Label()
        Me.btnCalc = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.rbStandard = New System.Windows.Forms.RadioButton()
        Me.rbDeluxe = New System.Windows.Forms.RadioButton()
        Me.rbPremium = New System.Windows.Forms.RadioButton()
        Me.rbBlue = New System.Windows.Forms.RadioButton()
        Me.rbRed = New System.Windows.Forms.RadioButton()
        Me.rbPink = New System.Windows.Forms.RadioButton()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rbPremium)
        Me.GroupBox1.Controls.Add(Me.rbDeluxe)
        Me.GroupBox1.Controls.Add(Me.rbStandard)
        Me.GroupBox1.Location = New System.Drawing.Point(13, 13)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(118, 99)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Type"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.rbPink)
        Me.GroupBox2.Controls.Add(Me.rbRed)
        Me.GroupBox2.Controls.Add(Me.rbBlue)
        Me.GroupBox2.Location = New System.Drawing.Point(157, 13)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(118, 99)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Color"
        '
        'chkFold
        '
        Me.chkFold.AutoSize = True
        Me.chkFold.Location = New System.Drawing.Point(301, 23)
        Me.chkFold.Name = "chkFold"
        Me.chkFold.Size = New System.Drawing.Size(119, 17)
        Me.chkFold.TabIndex = 2
        Me.chkFold.Text = "&Foldable ($25 extra)"
        Me.chkFold.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(299, 56)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(37, 13)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Price: "
        '
        'lblPrice
        '
        Me.lblPrice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblPrice.Location = New System.Drawing.Point(338, 52)
        Me.lblPrice.Name = "lblPrice"
        Me.lblPrice.Size = New System.Drawing.Size(119, 20)
        Me.lblPrice.TabIndex = 4
        Me.lblPrice.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnCalc
        '
        Me.btnCalc.Location = New System.Drawing.Point(301, 89)
        Me.btnCalc.Name = "btnCalc"
        Me.btnCalc.Size = New System.Drawing.Size(75, 23)
        Me.btnCalc.TabIndex = 5
        Me.btnCalc.Text = "&Calculate"
        Me.btnCalc.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(382, 89)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 6
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'rbStandard
        '
        Me.rbStandard.AutoSize = True
        Me.rbStandard.Location = New System.Drawing.Point(6, 19)
        Me.rbStandard.Name = "rbStandard"
        Me.rbStandard.Size = New System.Drawing.Size(95, 17)
        Me.rbStandard.TabIndex = 0
        Me.rbStandard.TabStop = True
        Me.rbStandard.Text = "&Standard ($99)"
        Me.rbStandard.UseVisualStyleBackColor = True
        '
        'rbDeluxe
        '
        Me.rbDeluxe.AutoSize = True
        Me.rbDeluxe.Location = New System.Drawing.Point(6, 42)
        Me.rbDeluxe.Name = "rbDeluxe"
        Me.rbDeluxe.Size = New System.Drawing.Size(91, 17)
        Me.rbDeluxe.TabIndex = 1
        Me.rbDeluxe.TabStop = True
        Me.rbDeluxe.Text = "&Deluxe ($129)"
        Me.rbDeluxe.UseVisualStyleBackColor = True
        '
        'rbPremium
        '
        Me.rbPremium.AutoSize = True
        Me.rbPremium.Location = New System.Drawing.Point(6, 65)
        Me.rbPremium.Name = "rbPremium"
        Me.rbPremium.Size = New System.Drawing.Size(98, 17)
        Me.rbPremium.TabIndex = 2
        Me.rbPremium.TabStop = True
        Me.rbPremium.Text = "&Premium ($179)"
        Me.rbPremium.UseVisualStyleBackColor = True
        '
        'rbBlue
        '
        Me.rbBlue.AutoSize = True
        Me.rbBlue.Location = New System.Drawing.Point(6, 19)
        Me.rbBlue.Name = "rbBlue"
        Me.rbBlue.Size = New System.Drawing.Size(46, 17)
        Me.rbBlue.TabIndex = 3
        Me.rbBlue.TabStop = True
        Me.rbBlue.Text = "&Blue"
        Me.rbBlue.UseVisualStyleBackColor = True
        '
        'rbRed
        '
        Me.rbRed.AutoSize = True
        Me.rbRed.Location = New System.Drawing.Point(6, 42)
        Me.rbRed.Name = "rbRed"
        Me.rbRed.Size = New System.Drawing.Size(98, 17)
        Me.rbRed.TabIndex = 4
        Me.rbRed.TabStop = True
        Me.rbRed.Text = "&Red ($10 extra)"
        Me.rbRed.UseVisualStyleBackColor = True
        '
        'rbPink
        '
        Me.rbPink.AutoSize = True
        Me.rbPink.Location = New System.Drawing.Point(6, 65)
        Me.rbPink.Name = "rbPink"
        Me.rbPink.Size = New System.Drawing.Size(99, 17)
        Me.rbPink.TabIndex = 5
        Me.rbPink.TabStop = True
        Me.rbPink.Text = "Pin&k ($15 extra)"
        Me.rbPink.UseVisualStyleBackColor = True
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(472, 127)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnCalc)
        Me.Controls.Add(Me.lblPrice)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.chkFold)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "frmMain"
        Me.Text = "Mats-R-Us"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents chkFold As CheckBox
    Friend WithEvents Label1 As Label
    Friend WithEvents lblPrice As Label
    Friend WithEvents btnCalc As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents rbPremium As RadioButton
    Friend WithEvents rbDeluxe As RadioButton
    Friend WithEvents rbStandard As RadioButton
    Friend WithEvents rbPink As RadioButton
    Friend WithEvents rbRed As RadioButton
    Friend WithEvents rbBlue As RadioButton
End Class

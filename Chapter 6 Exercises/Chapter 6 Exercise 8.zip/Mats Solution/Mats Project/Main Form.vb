﻿'Name:          Mats R Us Project
'Purpose:       Calculates the cose of a mat
'Programmer:    Dylan DeCoster on 10/22/19

Public Class frmMain
    Dim extra As Double

    'Shows Everything
    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        CalcExtra()
        Me.lblPrice.Text = "$" + (CalcPrice() + extra).ToString("N2")
    End Sub

    'Closes application
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()

    End Sub

    'Calculates the price of the main stuff
    Private Function CalcPrice() As Double
        Dim price As Double

        'Checks which one is checked
        Select Case True
            Case Me.rbStandard.Checked
                price = 99
            Case Me.rbDeluxe.Checked
                price = 129
            Case Me.rbPremium.Checked
                price = 179
        End Select

        'Returns the price of the one that is checked
        Return price
    End Function

    'Calculates all the extra things
    Private Sub CalcExtra()
        'Checks which one is checked and if the checkbox is checked also
        Select Case True
            Case Me.rbBlue.Checked
                If (Me.chkFold.Checked) Then
                    extra = 25
                Else
                    extra = 0
                End If
            Case Me.rbRed.Checked
                extra = 10
                If (Me.chkFold.Checked) Then
                    extra = 35
                End If
            Case Me.rbPink.Checked
                extra = 15
                If (Me.chkFold.Checked) Then
                    extra = 40
                End If
        End Select
    End Sub

    'Clears everything
    Private Sub ClearOutput(sender As Object, e As EventArgs) _
        Handles rbBlue.CheckedChanged, rbRed.CheckedChanged, rbPink.CheckedChanged,
        rbStandard.CheckedChanged, rbDeluxe.CheckedChanged, rbPremium.CheckedChanged, chkFold.CheckedChanged

        Me.lblPrice.Text = Nothing

    End Sub
End Class

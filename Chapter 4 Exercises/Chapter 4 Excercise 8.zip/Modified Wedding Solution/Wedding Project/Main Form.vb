﻿' Name:         Wedding Project
' Purpose:      Displays the number of tables needed.
' Programmer:   Dylan DeCoster on 10/15/19

Option Explicit On
Option Infer Off

Public Class frmMain
    Dim guests, bridal As Double

    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        ' Calculate and display the number of required tables.
        guests = Val(Me.txtGuests.Text)
        bridal = Val(Me.txtBridal.Text)

        Me.lblRound.Text = Math.Ceiling(guests / 8).ToString("N0")
        Me.lblRectangle.Text = Math.Ceiling(bridal / 10).ToString("N0")

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub txtGuests_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtGuests.KeyPress
        If ((e.KeyChar < "0" OrElse e.KeyChar > "9") AndAlso e.KeyChar <> ControlChars.Back) Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtBridal_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtBridal.KeyPress
        If ((e.KeyChar < "0" OrElse e.KeyChar > "9") AndAlso e.KeyChar <> ControlChars.Back) Then
            e.Handled = True
        End If
    End Sub
End Class

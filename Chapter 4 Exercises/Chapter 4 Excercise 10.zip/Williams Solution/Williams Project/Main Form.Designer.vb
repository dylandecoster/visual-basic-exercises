﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.rbDiamond = New System.Windows.Forms.RadioButton()
        Me.rbGold = New System.Windows.Forms.RadioButton()
        Me.rbSilver = New System.Windows.Forms.RadioButton()
        Me.rbBasic = New System.Windows.Forms.RadioButton()
        Me.btnCalc = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.chkCinnema = New System.Windows.Forms.CheckBox()
        Me.chkHBI = New System.Windows.Forms.CheckBox()
        Me.chkShowtimer = New System.Windows.Forms.CheckBox()
        Me.chkLocal = New System.Windows.Forms.CheckBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblTotal = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rbDiamond)
        Me.GroupBox1.Controls.Add(Me.rbGold)
        Me.GroupBox1.Controls.Add(Me.rbSilver)
        Me.GroupBox1.Controls.Add(Me.rbBasic)
        Me.GroupBox1.Location = New System.Drawing.Point(13, 13)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(111, 124)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Packages"
        '
        'rbDiamond
        '
        Me.rbDiamond.AutoSize = True
        Me.rbDiamond.Location = New System.Drawing.Point(7, 92)
        Me.rbDiamond.Name = "rbDiamond"
        Me.rbDiamond.Size = New System.Drawing.Size(67, 17)
        Me.rbDiamond.TabIndex = 3
        Me.rbDiamond.TabStop = True
        Me.rbDiamond.Text = "Diamond"
        Me.rbDiamond.UseVisualStyleBackColor = True
        '
        'rbGold
        '
        Me.rbGold.AutoSize = True
        Me.rbGold.Location = New System.Drawing.Point(7, 68)
        Me.rbGold.Name = "rbGold"
        Me.rbGold.Size = New System.Drawing.Size(47, 17)
        Me.rbGold.TabIndex = 2
        Me.rbGold.TabStop = True
        Me.rbGold.Text = "Gold"
        Me.rbGold.UseVisualStyleBackColor = True
        '
        'rbSilver
        '
        Me.rbSilver.AutoSize = True
        Me.rbSilver.Location = New System.Drawing.Point(7, 44)
        Me.rbSilver.Name = "rbSilver"
        Me.rbSilver.Size = New System.Drawing.Size(51, 17)
        Me.rbSilver.TabIndex = 1
        Me.rbSilver.TabStop = True
        Me.rbSilver.Text = "Silver"
        Me.rbSilver.UseVisualStyleBackColor = True
        '
        'rbBasic
        '
        Me.rbBasic.AutoSize = True
        Me.rbBasic.Location = New System.Drawing.Point(7, 20)
        Me.rbBasic.Name = "rbBasic"
        Me.rbBasic.Size = New System.Drawing.Size(51, 17)
        Me.rbBasic.TabIndex = 0
        Me.rbBasic.TabStop = True
        Me.rbBasic.Text = "Basic"
        Me.rbBasic.UseVisualStyleBackColor = True
        '
        'btnCalc
        '
        Me.btnCalc.Location = New System.Drawing.Point(132, 177)
        Me.btnCalc.Name = "btnCalc"
        Me.btnCalc.Size = New System.Drawing.Size(75, 23)
        Me.btnCalc.TabIndex = 1
        Me.btnCalc.Text = "Calculate"
        Me.btnCalc.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(223, 177)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 2
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'chkCinnema
        '
        Me.chkCinnema.AutoSize = True
        Me.chkCinnema.Location = New System.Drawing.Point(143, 34)
        Me.chkCinnema.Name = "chkCinnema"
        Me.chkCinnema.Size = New System.Drawing.Size(155, 17)
        Me.chkCinnema.TabIndex = 3
        Me.chkCinnema.Text = "Cinnematic movie channels"
        Me.chkCinnema.UseVisualStyleBackColor = True
        '
        'chkHBI
        '
        Me.chkHBI.AutoSize = True
        Me.chkHBI.Location = New System.Drawing.Point(143, 58)
        Me.chkHBI.Name = "chkHBI"
        Me.chkHBI.Size = New System.Drawing.Size(121, 17)
        Me.chkHBI.TabIndex = 4
        Me.chkHBI.Text = "HBI movie channels"
        Me.chkHBI.UseVisualStyleBackColor = True
        '
        'chkShowtimer
        '
        Me.chkShowtimer.AutoSize = True
        Me.chkShowtimer.Location = New System.Drawing.Point(143, 82)
        Me.chkShowtimer.Name = "chkShowtimer"
        Me.chkShowtimer.Size = New System.Drawing.Size(152, 17)
        Me.chkShowtimer.TabIndex = 5
        Me.chkShowtimer.Text = "Showtimer movie channels"
        Me.chkShowtimer.UseVisualStyleBackColor = True
        '
        'chkLocal
        '
        Me.chkLocal.AutoSize = True
        Me.chkLocal.Location = New System.Drawing.Point(143, 106)
        Me.chkLocal.Name = "chkLocal"
        Me.chkLocal.Size = New System.Drawing.Size(91, 17)
        Me.chkLocal.TabIndex = 6
        Me.chkLocal.Text = "Local stations"
        Me.chkLocal.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(10, 161)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(61, 13)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "Total Cost: "
        '
        'lblTotal
        '
        Me.lblTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTotal.Location = New System.Drawing.Point(13, 177)
        Me.lblTotal.Name = "lblTotal"
        Me.lblTotal.Size = New System.Drawing.Size(100, 23)
        Me.lblTotal.TabIndex = 8
        Me.lblTotal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(310, 212)
        Me.Controls.Add(Me.lblTotal)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.chkLocal)
        Me.Controls.Add(Me.chkShowtimer)
        Me.Controls.Add(Me.chkHBI)
        Me.Controls.Add(Me.chkCinnema)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnCalc)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "frmMain"
        Me.Text = "Williams"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents rbDiamond As RadioButton
    Friend WithEvents rbGold As RadioButton
    Friend WithEvents rbSilver As RadioButton
    Friend WithEvents rbBasic As RadioButton
    Friend WithEvents btnCalc As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents chkCinnema As CheckBox
    Friend WithEvents chkHBI As CheckBox
    Friend WithEvents chkShowtimer As CheckBox
    Friend WithEvents chkLocal As CheckBox
    Friend WithEvents Label1 As Label
    Friend WithEvents lblTotal As Label
End Class

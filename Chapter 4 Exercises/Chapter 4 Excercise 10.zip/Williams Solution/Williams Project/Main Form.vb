﻿'Name:          Williams Cable Company
'Purpose:       Calculate the cost of cable
'Programmer:    Dylan DeCoster on 10/16/19

Public Class frmMain
    Dim total As Double

    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        'Finds which radio button is selected
        Select Case True
            Case Me.rbBasic.Checked
                total = 24.99
            Case Me.rbSilver.Checked
                total = 42.99
            Case Me.rbGold.Checked
                total = 84.99
            Case Me.rbDiamond.Checked
                total = 99.99
        End Select

        'Checks for what checkboxes are checked and adds price accordingly
        If (Me.chkHBI.Checked) Then
            total += 9.5
        End If
        If (Me.chkCinnema.Checked) Then
            total += 9.5
        End If
        If (Me.chkShowtimer.Checked) Then
            total += 10.5
        End If
        If (Me.chkLocal.Checked) Then
            total += 6.0
        End If

        'Formats and prints the total cost
        Me.lblTotal.Text = "$" + total.ToString("N2")
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()

    End Sub
End Class

﻿Public Class frmMain
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnCost.Click
        Dim price As Double

        If (Me.chkPickup.Checked) Then
            price -= 5.0
        End If

        If (Me.rbTwin.Checked) Then
            price += 44.99
        ElseIf (Me.rbFull.Checked) Then
            price += 54.99
        ElseIf (Me.rbQueen.Checked) Then
            price += 54.99
        ElseIf (Me.rbKing.Checked) Then
            price += 74.99
        End If

        Me.lblTotal.Text = "$" + price.ToString("N2")
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()

    End Sub
End Class

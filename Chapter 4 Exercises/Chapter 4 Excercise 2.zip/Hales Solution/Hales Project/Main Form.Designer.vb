﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.grpSize = New System.Windows.Forms.GroupBox()
        Me.chkPickup = New System.Windows.Forms.CheckBox()
        Me.lblCost = New System.Windows.Forms.Label()
        Me.btnCost = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.rbTwin = New System.Windows.Forms.RadioButton()
        Me.rbFull = New System.Windows.Forms.RadioButton()
        Me.rbQueen = New System.Windows.Forms.RadioButton()
        Me.rbKing = New System.Windows.Forms.RadioButton()
        Me.lblTotal = New System.Windows.Forms.Label()
        Me.grpSize.SuspendLayout()
        Me.SuspendLayout()
        '
        'grpSize
        '
        Me.grpSize.Controls.Add(Me.rbKing)
        Me.grpSize.Controls.Add(Me.rbQueen)
        Me.grpSize.Controls.Add(Me.rbFull)
        Me.grpSize.Controls.Add(Me.rbTwin)
        Me.grpSize.Location = New System.Drawing.Point(12, 12)
        Me.grpSize.Name = "grpSize"
        Me.grpSize.Size = New System.Drawing.Size(110, 123)
        Me.grpSize.TabIndex = 0
        Me.grpSize.TabStop = False
        Me.grpSize.Text = "Size"
        '
        'chkPickup
        '
        Me.chkPickup.AutoSize = True
        Me.chkPickup.Location = New System.Drawing.Point(128, 17)
        Me.chkPickup.Name = "chkPickup"
        Me.chkPickup.Size = New System.Drawing.Size(99, 17)
        Me.chkPickup.TabIndex = 1
        Me.chkPickup.Text = "&Pick up in store"
        Me.chkPickup.UseVisualStyleBackColor = True
        '
        'lblCost
        '
        Me.lblCost.AutoSize = True
        Me.lblCost.Location = New System.Drawing.Point(125, 40)
        Me.lblCost.Name = "lblCost"
        Me.lblCost.Size = New System.Drawing.Size(34, 13)
        Me.lblCost.TabIndex = 2
        Me.lblCost.Text = "Cost: "
        '
        'btnCost
        '
        Me.btnCost.Location = New System.Drawing.Point(129, 84)
        Me.btnCost.Name = "btnCost"
        Me.btnCost.Size = New System.Drawing.Size(99, 23)
        Me.btnCost.TabIndex = 4
        Me.btnCost.Text = "&Display cost"
        Me.btnCost.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(129, 111)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(99, 23)
        Me.btnExit.TabIndex = 5
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'rbTwin
        '
        Me.rbTwin.AutoSize = True
        Me.rbTwin.Location = New System.Drawing.Point(7, 20)
        Me.rbTwin.Name = "rbTwin"
        Me.rbTwin.Size = New System.Drawing.Size(48, 17)
        Me.rbTwin.TabIndex = 0
        Me.rbTwin.TabStop = True
        Me.rbTwin.Text = "&Twin"
        Me.rbTwin.UseVisualStyleBackColor = True
        '
        'rbFull
        '
        Me.rbFull.AutoSize = True
        Me.rbFull.Location = New System.Drawing.Point(7, 43)
        Me.rbFull.Name = "rbFull"
        Me.rbFull.Size = New System.Drawing.Size(41, 17)
        Me.rbFull.TabIndex = 1
        Me.rbFull.TabStop = True
        Me.rbFull.Text = "&Full"
        Me.rbFull.UseVisualStyleBackColor = True
        '
        'rbQueen
        '
        Me.rbQueen.AutoSize = True
        Me.rbQueen.Location = New System.Drawing.Point(7, 69)
        Me.rbQueen.Name = "rbQueen"
        Me.rbQueen.Size = New System.Drawing.Size(57, 17)
        Me.rbQueen.TabIndex = 2
        Me.rbQueen.TabStop = True
        Me.rbQueen.Text = "&Queen"
        Me.rbQueen.UseVisualStyleBackColor = True
        '
        'rbKing
        '
        Me.rbKing.AutoSize = True
        Me.rbKing.Location = New System.Drawing.Point(7, 93)
        Me.rbKing.Name = "rbKing"
        Me.rbKing.Size = New System.Drawing.Size(46, 17)
        Me.rbKing.TabIndex = 3
        Me.rbKing.TabStop = True
        Me.rbKing.Text = "&King"
        Me.rbKing.UseVisualStyleBackColor = True
        '
        'lblTotal
        '
        Me.lblTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTotal.Location = New System.Drawing.Point(128, 54)
        Me.lblTotal.Name = "lblTotal"
        Me.lblTotal.Size = New System.Drawing.Size(100, 23)
        Me.lblTotal.TabIndex = 6
        Me.lblTotal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(237, 153)
        Me.Controls.Add(Me.lblTotal)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnCost)
        Me.Controls.Add(Me.lblCost)
        Me.Controls.Add(Me.chkPickup)
        Me.Controls.Add(Me.grpSize)
        Me.Name = "frmMain"
        Me.Text = "Hales Department Store"
        Me.grpSize.ResumeLayout(False)
        Me.grpSize.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents grpSize As GroupBox
    Friend WithEvents rbKing As RadioButton
    Friend WithEvents rbQueen As RadioButton
    Friend WithEvents rbFull As RadioButton
    Friend WithEvents rbTwin As RadioButton
    Friend WithEvents chkPickup As CheckBox
    Friend WithEvents lblCost As Label
    Friend WithEvents btnCost As Button
    Friend WithEvents lblTotal As Label
    Friend WithEvents btnExit As Button
End Class

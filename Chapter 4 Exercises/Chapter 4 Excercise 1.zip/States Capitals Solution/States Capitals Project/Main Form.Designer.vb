﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnDisplay = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblCapital = New System.Windows.Forms.Label()
        Me.rbOklahoma = New System.Windows.Forms.RadioButton()
        Me.rbFlorida = New System.Windows.Forms.RadioButton()
        Me.rbTexas = New System.Windows.Forms.RadioButton()
        Me.rbKansas = New System.Windows.Forms.RadioButton()
        Me.rbAlabama = New System.Windows.Forms.RadioButton()
        Me.SuspendLayout()
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(155, 171)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 0
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnDisplay
        '
        Me.btnDisplay.Location = New System.Drawing.Point(13, 171)
        Me.btnDisplay.Name = "btnDisplay"
        Me.btnDisplay.Size = New System.Drawing.Size(75, 23)
        Me.btnDisplay.TabIndex = 1
        Me.btnDisplay.Text = "Display"
        Me.btnDisplay.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(127, 84)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(45, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Capital: "
        '
        'lblCapital
        '
        Me.lblCapital.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblCapital.Location = New System.Drawing.Point(130, 102)
        Me.lblCapital.Name = "lblCapital"
        Me.lblCapital.Size = New System.Drawing.Size(100, 23)
        Me.lblCapital.TabIndex = 3
        Me.lblCapital.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'rbOklahoma
        '
        Me.rbOklahoma.AutoSize = True
        Me.rbOklahoma.Location = New System.Drawing.Point(12, 12)
        Me.rbOklahoma.Name = "rbOklahoma"
        Me.rbOklahoma.Size = New System.Drawing.Size(73, 17)
        Me.rbOklahoma.TabIndex = 4
        Me.rbOklahoma.TabStop = True
        Me.rbOklahoma.Text = "Oklahoma"
        Me.rbOklahoma.UseVisualStyleBackColor = True
        '
        'rbFlorida
        '
        Me.rbFlorida.AutoSize = True
        Me.rbFlorida.Location = New System.Drawing.Point(12, 36)
        Me.rbFlorida.Name = "rbFlorida"
        Me.rbFlorida.Size = New System.Drawing.Size(56, 17)
        Me.rbFlorida.TabIndex = 5
        Me.rbFlorida.TabStop = True
        Me.rbFlorida.Text = "Florida"
        Me.rbFlorida.UseVisualStyleBackColor = True
        '
        'rbTexas
        '
        Me.rbTexas.AutoSize = True
        Me.rbTexas.Location = New System.Drawing.Point(12, 59)
        Me.rbTexas.Name = "rbTexas"
        Me.rbTexas.Size = New System.Drawing.Size(54, 17)
        Me.rbTexas.TabIndex = 6
        Me.rbTexas.TabStop = True
        Me.rbTexas.Text = "Texas"
        Me.rbTexas.UseVisualStyleBackColor = True
        '
        'rbKansas
        '
        Me.rbKansas.AutoSize = True
        Me.rbKansas.Location = New System.Drawing.Point(12, 84)
        Me.rbKansas.Name = "rbKansas"
        Me.rbKansas.Size = New System.Drawing.Size(60, 17)
        Me.rbKansas.TabIndex = 7
        Me.rbKansas.TabStop = True
        Me.rbKansas.Text = "Kansas"
        Me.rbKansas.UseVisualStyleBackColor = True
        '
        'rbAlabama
        '
        Me.rbAlabama.AutoSize = True
        Me.rbAlabama.Location = New System.Drawing.Point(12, 108)
        Me.rbAlabama.Name = "rbAlabama"
        Me.rbAlabama.Size = New System.Drawing.Size(66, 17)
        Me.rbAlabama.TabIndex = 8
        Me.rbAlabama.TabStop = True
        Me.rbAlabama.Text = "Alabama"
        Me.rbAlabama.UseVisualStyleBackColor = True
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(254, 215)
        Me.Controls.Add(Me.rbAlabama)
        Me.Controls.Add(Me.rbKansas)
        Me.Controls.Add(Me.rbTexas)
        Me.Controls.Add(Me.rbFlorida)
        Me.Controls.Add(Me.rbOklahoma)
        Me.Controls.Add(Me.lblCapital)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnDisplay)
        Me.Controls.Add(Me.btnExit)
        Me.Name = "frmMain"
        Me.Text = "States Capitals"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnExit As Button
    Friend WithEvents btnDisplay As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents lblCapital As Label
    Friend WithEvents rbOklahoma As RadioButton
    Friend WithEvents rbFlorida As RadioButton
    Friend WithEvents rbTexas As RadioButton
    Friend WithEvents rbKansas As RadioButton
    Friend WithEvents rbAlabama As RadioButton
End Class

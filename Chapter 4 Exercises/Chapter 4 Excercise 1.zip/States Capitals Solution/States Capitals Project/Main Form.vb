﻿'Name:          States Capitals
'Purpose:       Show the state capital for one of the five states
'Programmer:    Dylan DeCoster on 10/14/19

Public Class frmMain
    Private Sub btnDisplay_Click(sender As Object, e As EventArgs) Handles btnDisplay.Click
        'Checks what radio button is clicked then sets the lblCapital text
        If (Me.rbOklahoma.Checked) Then
            Me.lblCapital.Text = "Oklahoma City"
        ElseIf (Me.rbFlorida.Checked) Then
            Me.lblCapital.Text = "Tallahassee"
        ElseIf (Me.rbTexas.Checked) Then
            Me.lblCapital.Text = "Austin"
        ElseIf (Me.rbKansas.Checked) Then
            Me.lblCapital.Text = "Topeka"
        ElseIf (Me.rbAlabama.Checked) Then
            Me.lblCapital.Text = "Montgomery"
        End If
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()

    End Sub
End Class

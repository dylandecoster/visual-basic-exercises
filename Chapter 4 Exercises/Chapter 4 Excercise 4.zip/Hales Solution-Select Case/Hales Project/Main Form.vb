﻿Public Class frmMain
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnCost.Click
        Dim price As Double

        If (Me.chkPickup.Checked) Then
            price -= 5.0
        End If

        Select Case True
            Case Me.rbTwin.Checked
                price += 44.99
            Case Me.rbFull.Checked
                price += 54.99
            Case Me.rbQueen.Checked
                price += 54.99
            Case Me.rbKing.Checked
                price += 74.99
        End Select

        Me.lblTotal.Text = "$" + price.ToString("N2")
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()

    End Sub
End Class

﻿Public Class frmMain
    Dim price As Double

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnGetPrice.Click
        'Checks and sets the price for the edition
        Select Case True
            Case Me.rbUltimate.Checked
                price = 899.99
            Case Me.rbProfessional.Checked
                price = 599.99
            Case Me.rbStudent.Checked
                price = 99.99
        End Select

        'Checks and applies the coupon
        Select Case True
            Case Me.rbUltimateDiscount.Checked
                price -= (price * 0.1)
            Case Me.rbStudentDiscount.Checked
                price -= (price * 0.2)
        End Select

        'Formats and prints the price
        Me.lblPrice.Text = "$" + price.ToString("N2")
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()

    End Sub
End Class

﻿'Name:          Car Project
'Purpose:       Show which car saves more
'Programmer:    Dylan DeCoster on 10/15/19

Public Class frmMain
    Dim miles, mpg1, mpg2, cpg1, cpg2, cost1, cost2 As Double

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        'Gets all the input
        miles = Val(Me.txtMiles.Text)
        mpg1 = Val(Me.txtMpg1.Text)
        mpg2 = Val(Me.txtMpg2.Text)
        cpg1 = Val(Me.txtCpg1.Text)
        cpg2 = Val(Me.txtCpg2.Text)

        'Calculates the cost
        cost1 = (miles / mpg1) * (cpg1)
        cost2 = (miles / mpg2) * (cpg2)

        'Shows the costs
        Me.lblCost1.Text = cost1.ToString("N2")
        Me.lblCost2.Text = cost2.ToString("N2")

        'Checks which one saves more
        If (cost1 < cost2) Then
            Me.lblAnswer.Text = "You save approximately $" + (cost2 - cost1).ToString() + " with Car 1 and the total cost of gas is $" + cost1.ToString("N2")
        ElseIf (cost2 < cost1) Then
            Me.lblAnswer.Text = "You save approximately $" + (cost1 - cost2).ToString("N0") + " with Car 1 and the total cost of gas is $" + cost2.ToString("N2")
        Else
            Me.lblAnswer.Text = "Both are equal so take Car 1"
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()

    End Sub
End Class

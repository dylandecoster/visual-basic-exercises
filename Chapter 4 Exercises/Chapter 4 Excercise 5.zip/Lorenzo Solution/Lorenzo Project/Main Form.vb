﻿'Name:          Lorenzo Project
'Purpose:       Calculates a BoGoHo
'Programmer:    Dylan DeCoster on 10/15/19

Public Class frmMain
    Dim first, second, total, saved As Double

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        'Gets the input of both text areas
        first = Val(Me.txtFirst.Text)
        second = Val(Me.txtSecond.Text)

        'Checks which one costs less then calculates the savings
        If (first > second) Then
            total = first + (second / 2)
            saved = second / 2
        Else
            total = second + (first / 2)
            saved = first / 2
        End If

        'Formats everything and inputs it into the label
        Me.lblTotal.Text = "$" + total.ToString("N2")
        Me.lblSaved.Text = "$" + saved.ToString("N2")
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'Exits the application
        Me.Close()

    End Sub
End Class

﻿'Name: Baxters Project
'Purpose: Calculate the price of a drill
'Programmer: Dylan DeCoster on 10/14/19

Public Class frmMain
    Const drillPrice As Double = 25.99
    Const discount As Double = 0.1
    Dim shippingFee As Double = 9.99
    Dim price As Double = 0

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        'Gets the input and mulitplies it with the price of a drill
        price = Val(Me.txtOrdered.Text) * drillPrice

        'Calculates the discount
        If (Me.chkDiscount.Checked) Then
            price -= price * discount
        End If

        'Changes the shipping price
        If (Me.chkCoupon.Checked) Then
            shippingFee = 4.99
        Else
            shippingFee = 9.99
        End If

        'Prints and formats everything
        Me.lblTotal.Text = "$" + (price + shippingFee).ToString("N2")
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()

    End Sub
End Class

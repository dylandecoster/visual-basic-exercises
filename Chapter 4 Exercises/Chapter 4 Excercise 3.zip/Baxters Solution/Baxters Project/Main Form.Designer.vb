﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblOrdered = New System.Windows.Forms.Label()
        Me.txtOrdered = New System.Windows.Forms.TextBox()
        Me.chkDiscount = New System.Windows.Forms.CheckBox()
        Me.chkCoupon = New System.Windows.Forms.CheckBox()
        Me.btnCalc = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblTotal = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lblOrdered
        '
        Me.lblOrdered.AutoSize = True
        Me.lblOrdered.Location = New System.Drawing.Point(13, 13)
        Me.lblOrdered.Name = "lblOrdered"
        Me.lblOrdered.Size = New System.Drawing.Size(51, 13)
        Me.lblOrdered.TabIndex = 0
        Me.lblOrdered.Text = "&Ordered: "
        '
        'txtOrdered
        '
        Me.txtOrdered.Location = New System.Drawing.Point(16, 34)
        Me.txtOrdered.Name = "txtOrdered"
        Me.txtOrdered.Size = New System.Drawing.Size(36, 20)
        Me.txtOrdered.TabIndex = 1
        '
        'chkDiscount
        '
        Me.chkDiscount.AutoSize = True
        Me.chkDiscount.Location = New System.Drawing.Point(65, 13)
        Me.chkDiscount.Name = "chkDiscount"
        Me.chkDiscount.Size = New System.Drawing.Size(115, 17)
        Me.chkDiscount.TabIndex = 2
        Me.chkDiscount.Text = "&Employee discount"
        Me.chkDiscount.UseVisualStyleBackColor = True
        '
        'chkCoupon
        '
        Me.chkCoupon.AutoSize = True
        Me.chkCoupon.Location = New System.Drawing.Point(65, 37)
        Me.chkCoupon.Name = "chkCoupon"
        Me.chkCoupon.Size = New System.Drawing.Size(134, 17)
        Me.chkCoupon.TabIndex = 3
        Me.chkCoupon.Text = "$4.99 &shipping coupon"
        Me.chkCoupon.UseVisualStyleBackColor = True
        '
        'btnCalc
        '
        Me.btnCalc.Location = New System.Drawing.Point(197, 7)
        Me.btnCalc.Name = "btnCalc"
        Me.btnCalc.Size = New System.Drawing.Size(75, 23)
        Me.btnCalc.TabIndex = 4
        Me.btnCalc.Text = "&Calculate"
        Me.btnCalc.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(197, 37)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 5
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(16, 81)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(58, 13)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Total due: "
        '
        'lblTotal
        '
        Me.lblTotal.BackColor = System.Drawing.SystemColors.Info
        Me.lblTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTotal.Location = New System.Drawing.Point(80, 76)
        Me.lblTotal.Name = "lblTotal"
        Me.lblTotal.Size = New System.Drawing.Size(100, 23)
        Me.lblTotal.TabIndex = 7
        Me.lblTotal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(290, 128)
        Me.Controls.Add(Me.lblTotal)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnCalc)
        Me.Controls.Add(Me.chkCoupon)
        Me.Controls.Add(Me.chkDiscount)
        Me.Controls.Add(Me.txtOrdered)
        Me.Controls.Add(Me.lblOrdered)
        Me.Name = "frmMain"
        Me.Text = "Baxters"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblOrdered As Label
    Friend WithEvents txtOrdered As TextBox
    Friend WithEvents chkDiscount As CheckBox
    Friend WithEvents chkCoupon As CheckBox
    Friend WithEvents btnCalc As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents lblTotal As Label
End Class

﻿' Name:         Addition Project
' Purpose:      Display a random addition problem and verify user's answer.
' Programmer:   Dylan DeCoster on 10/24/19

Option Explicit On
Option Strict On
Option Infer Off

Public Class frmMain
    Dim num1 As Integer
    Dim num2 As Integer

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnNew_Click(sender As Object, e As EventArgs) Handles btnNew.Click
        'Generates a random number between 1 and 10
        num1 = CInt(Math.Ceiling(Rnd() * 10)) + 1
        num2 = CInt(Math.Ceiling(Rnd() * 10)) + 1
        'Shows the numbers
        Me.lblNum1.Text = num1.ToString()
        Me.lblNum2.Text = num2.ToString()
        'Enables the button
        btnCheck.Enabled = True
    End Sub

    Private Sub btnCheck_Click(sender As Object, e As EventArgs) Handles btnCheck.Click
        Dim sum As Double
        sum = Val(Me.txtAnswer.Text)
        'Checks the answer
        If num1 + num2 = sum Then
            MessageBox.Show("Correct!", "Addition", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Me.lblNum1.Text = Nothing
            Me.lblNum2.Text = Nothing
            Me.txtAnswer.Text = Nothing

            sum = Nothing
            num1 = Nothing
            num2 = Nothing

            btnCheck.Enabled = False
        Else
            MessageBox.Show("Incorrect!", "Addition", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End If
    End Sub
End Class

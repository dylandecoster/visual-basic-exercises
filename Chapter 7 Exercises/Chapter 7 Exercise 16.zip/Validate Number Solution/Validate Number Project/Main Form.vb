﻿' Name:         Validate Number Project
' Purpose:      Validate a 9-digit number.
' Programmer:   Dylan DeCoster on 10/28/19

Option Explicit On
Option Strict On
Option Infer Off

Public Class frmMain
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnValidate_Click(sender As Object, e As EventArgs) Handles btnValidate.Click
        Dim num As Integer
        Dim temp As Integer
        Dim odd As Integer
        Dim remainder As Integer
        num = Integer.Parse(Me.txtNumber.Text)
        odd = Integer.Parse(Me.txtNumber.Text)

        'Repeats the length of the number
        For numLength As Integer = 1 To odd.ToString().Length
            'If the number is even
            If numLength Mod 2 = 0 Then
                'Checks if that number is greater than 9
                If CInt(num.ToString().Substring(numLength, 1)) * 2 > 9 Then
                    'Puts the number in temp and multiplies it by 2
                    temp = (CInt(num.ToString().Substring(numLength, 1)) * 2)
                    'Gets the first number in temp and adds it to the second number in temp
                    num += CInt(temp.ToString().Substring(0, 1) + temp.ToString().Substring(1, 1))
                    'Else adds that number to num
                Else
                    num += CInt(num.ToString().Substring(numLength - 1, 1)) * 2
                End If
                'Else if the number is odd
            Else
                'Adds the odd number to odd
                odd += CInt(odd.ToString().Substring(numLength - 1, 1))
            End If
        Next numLength

        'Gets the remainder
        remainder = (num + odd) Mod 10
        'Checks if the number is valid or invalid
        If (remainder = 0) Then
            Me.lblStatus.Text = "Valid"
        Else
            Me.lblStatus.Text = "Invalid"
        End If
    End Sub
End Class
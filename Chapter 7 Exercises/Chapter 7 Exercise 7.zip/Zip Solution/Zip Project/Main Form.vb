' Name:         Zip Project
' Purpose:      Validate a ZIP code.
' Programmer:   Dylan DeCoster on 10/23/19

Option Explicit On
Option Strict On
Option Infer Off

Public Class frmMain
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub txtZip_Enter(sender As Object, e As EventArgs) Handles txtZip.Enter
        txtZip.SelectAll()
    End Sub

    Private Sub txtZip_TextChanged(sender As Object, e As EventArgs) Handles txtZip.TextChanged
        lblStatus.Text = String.Empty
    End Sub

    Private Sub txtZip_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtZip.KeyPress
        ' Allow only numbers and the Backspace key.

        If (e.KeyChar < "0" OrElse e.KeyChar > "9") AndAlso e.KeyChar <> ControlChars.Back Then
            e.Handled = True
        End If
    End Sub

    Private Sub btnDisplay_Click(sender As Object, e As EventArgs) Handles btnDisplay.Click
        Dim zip As String = Me.txtZip.Text

        'Makes sure the length is at least 5
        If (zip.Length >= 5) Then
            'Makes sure the zip starts with 4210
            If (zip.Substring(0, 4) = "4210") Then
                'Checks the last number and makes sure its either 2 3 or 4
                If (zip.Substring(zip.Length - 1, 1) = "2" Or
                    zip.Substring(zip.Length - 1, 1) = "3" Or
                    zip.Substring(zip.Length - 1, 1) = "4") Then

                    Me.lblStatus.Text = "Valid"
                End If
            Else
                Me.lblStatus.Text = "Not valid"
            End If
        Else
            Me.lblStatus.Text = "Not valid"
        End If
    End Sub
End Class

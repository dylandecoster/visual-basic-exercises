' Name:         Color Project
' Purpose:      Displays an item's color.
' Programmer:   Dylan DeCoster on 10/23/19

Option Explicit On
Option Strict On
Option Infer Off

Public Class frmMain
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub txtItem_TextChanged(sender As Object, e As EventArgs) Handles txtItem.TextChanged
        lblColor.Text = String.Empty
    End Sub

    Private Sub txtItem_Enter(sender As Object, e As EventArgs) Handles txtItem.Enter
        txtItem.SelectAll()
    End Sub

    Private Sub btnDisplay_Click(sender As Object, e As EventArgs) Handles btnDisplay.Click
        Dim color As String
        Dim length As Integer
        'Gets the length
        length = Me.txtItem.Text.Length

        'Makes sure the length is 5
        If (length = 5) Then
            'Gets the third character
            color = (Me.txtItem.Text).Substring(2, 1)
            'Displays the correct color
            If (color = "b" Or color = "B") Then
                Me.lblColor.Text = "Blue"
            ElseIf (color = "g" Or color = "G") Then
                Me.lblColor.Text = "Green"
            ElseIf (color = "r" Or color = "R") Then
                Me.lblColor.Text = "Red"
            ElseIf (color = "w" Or color = "W") Then
                Me.lblColor.Text = "White"
            Else
                Me.lblColor.Text = "Error"
            End If
        Else
            Me.lblColor.Text = "Error"
        End If
    End Sub
End Class

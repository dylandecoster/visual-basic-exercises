﻿'Name:          OnYourOwn
'Purpose:       Check what type of number the input is
'Programmer:    Dylan DeCoster on 10/28/19

Public Class frmMain
    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        Dim num As Integer
        num = Me.txtEnter.Text
        Dim divide As Integer
        divide = num Mod 2

        'Checks if the number is 0
        If (num = 0) Then
            Me.lblAnswer.Text = "Zero"
            'Checks if the number is even
        ElseIf divide = 0 Then
            Me.lblAnswer.Text = "Even"
            'Checks if the number is odd
        ElseIf divide <> 0 Then
            Me.lblAnswer.Text = "Odd"
        End If
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class

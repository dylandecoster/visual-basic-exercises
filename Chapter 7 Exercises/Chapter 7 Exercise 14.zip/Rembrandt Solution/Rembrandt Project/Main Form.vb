﻿'Name:          Rembrandt
'Purpose:       Calculate employees and how many they each sold
'Programmer:    Dylan DeCoster on 10/24/19

Public Class frmMain
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        Dim strID As String
        Dim numSold As Double
        Dim fullCount, partCount, newCount, usedCount As Integer

        strID = Me.txtID.Text
        numSold = Val(Me.txtNumSold.Text)

        'Makes sure the ID is valid
        If strID Like "###??" Then
            'Checks for New and Used
            Select Case True
                Case strID.ToUpper Like "###N?"
                    newCount += numSold
                Case strID.ToUpper Like "###U?"
                    usedCount += numSold
                Case Else
                    MessageBox.Show("Invalid ID", "Rembrandt Auto-Mart", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End Select
            'Checks for Full Time and Part Time
            Select Case True
                Case strID.ToUpper Like "###?F"
                    fullCount += numSold
                Case strID.ToUpper Like "###?P"
                    partCount += numSold
                Case Else
                    MessageBox.Show("Invalid ID", "Rembrandt Auto-Mart", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End Select
        Else
            'Shows an invalid entry
            MessageBox.Show("Invalid ID", "Rembrandt Auto-Mart", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End If

        Me.lblFull.Text = fullCount
        Me.lblNew.Text = newCount
        Me.lblPart.Text = partCount
        Me.lblUsed.Text = usedCount
    End Sub
End Class

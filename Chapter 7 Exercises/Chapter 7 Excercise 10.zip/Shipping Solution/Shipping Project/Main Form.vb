' Name:         Shipping Project
' Purpose:      Selects the delivery method in a list box.
' Programmer:   Dylan DeCoster on 10/24/19

Option Explicit On
Option Strict On
Option Infer Off

Public Class frmMain
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles Me.Load
        ' Fills the list box with values.

        lstDelivery.Items.Add("Mail - Standard")
        lstDelivery.Items.Add("Mail - Priority")
        lstDelivery.Items.Add("FedEx - Standard")
        lstDelivery.Items.Add("FedEx - Overnight")
        lstDelivery.Items.Add("UPS")
    End Sub

    Private Sub txtCode_Enter(sender As Object, e As EventArgs) Handles txtCode.Enter
        txtCode.SelectAll()
    End Sub

    Private Sub txtCode_TextChanged(sender As Object, e As EventArgs) Handles txtCode.TextChanged
        ' Clears the list box selection.

        lstDelivery.SelectedIndex = -1
    End Sub

    Private Sub btnDelivery_Click(sender As Object, e As EventArgs) Handles btnDelivery.Click
        Dim str As String
        str = Me.txtCode.Text

        'Checks if you are using Mail Standard
        If str.ToUpper Like "##MS" Then
            Me.lstDelivery.SetSelected(0, True)
            'Checks if you are using Mail Priority
        ElseIf str.ToUpper Like "##MP" Then
            Me.lstDelivery.SetSelected(1, True)
            'Checks if you are using FedEx Standard
        ElseIf str.ToUpper Like "##FS" Then
            Me.lstDelivery.SetSelected(2, True)
            'Checks if you are using FedEx Overnight
        ElseIf str.ToUpper Like "##FO" Then
            Me.lstDelivery.SetSelected(3, True)
            'Checks if you are using UPS
        ElseIf str.ToUpper Like "##U" Then
            Me.lstDelivery.SetSelected(4, True)
            'Shows a messagebox if you have an invalid entry
        Else
            MessageBox.Show("Invalid Entry.", "Shipping", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End If
    End Sub
End Class

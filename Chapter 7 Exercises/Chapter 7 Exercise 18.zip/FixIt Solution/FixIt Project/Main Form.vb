﻿' Name:         Reverse Project
' Purpose:      Reverses the characters in a word.
' Programmer:   Dylan DeCoster on 10/28/19

Option Explicit On
Option Strict On
Option Infer Off

Public Class frmMain
    Private Sub btnReverse_Click(sender As Object, e As EventArgs) Handles btnReverse.Click
        ' Displays the characters in reverse order.

        Dim strWord As String
        strWord = txtWord.Text.Trim
        Dim temp As String = ""

        'Goes the length of the word
        For intIndex As Integer = strWord.Length - 1 To 0 Step -1
            'Assigns the last letter to temp
            temp += strWord.Substring(intIndex, 1)
        Next intIndex
        'Prints temp
        Me.lblReverse.Text = temp
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub txtWord_Enter(sender As Object, e As EventArgs) Handles txtWord.Enter
        txtWord.SelectAll()
    End Sub

    Private Sub txtWord_TextChanged(sender As Object, e As EventArgs) Handles txtWord.TextChanged
        lblReverse.Text = String.Empty
    End Sub
End Class

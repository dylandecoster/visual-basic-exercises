﻿Public Class frmMain
    Dim check As Check

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        check = New Check(Me.txtNum.Text, Me.txtDate.Text, Me.txtAmount.Text, Me.txtPayee.Text)
        check.WriteCheck()
    End Sub
End Class

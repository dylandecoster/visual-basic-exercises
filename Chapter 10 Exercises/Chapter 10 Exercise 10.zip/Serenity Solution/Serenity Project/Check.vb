﻿Public Class Check
    Dim outFile As IO.StreamWriter

    Public ReadOnly Property Check As String

    Public Sub New()
        Check = ""
    End Sub

    Public Sub New(ByVal strN As String, ByVal strD As String, ByVal strA As String, ByVal strP As String)
        Check = strN + " " + strD + " " + strA + " " + strP
    End Sub

    Public Function WriteCheck() As IO.StreamWriter
        outFile = IO.File.AppendText("check.txt")
        outFile.WriteLine(Check)
        outFile.WriteLine()
        outFile.Close()

        Return outFile
    End Function
End Class

﻿'Name:          Glasgow Project
'Purpose:       Calculate fees
'Programmer:    Dylan DeCoster on 11/4/19

Public Class frmMain
    Dim basic As Double
    Dim additional As Double
    Dim monthly As Dues

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnExit.Click, btnExit.Click
        Me.Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        'Checks the basic and additional fees
        If Me.rbSingle.Checked Then
            basic = 50
            If chkGolf.Checked Then
                additional += 25
            End If
            If chkTennis.Checked Then
                additional += 30
            End If
            If chkRac.Checked Then
                additional += 25
            End If
        ElseIf Me.rbFamily.Checked Then
            basic = 90
            If chkGolf.Checked Then
                additional += 35
            End If
            If chkTennis.Checked Then
                additional += 50
            End If
            If chkRac.Checked Then
                additional += 30
            End If
        End If

        'Sets the text ares
        Me.lblBasic.Text = basic
        Me.lblAdditional.Text = additional

        'Sets the variables in monthly
        monthly = New Dues(basic, additional)
        'Calls the method
        Me.lblMonthly.Text = monthly.Monthly

        'Resets everything
        additional = 0
        basic = 0
    End Sub
End Class

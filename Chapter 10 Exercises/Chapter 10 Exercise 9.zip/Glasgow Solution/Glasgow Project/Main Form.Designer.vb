﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.rbSingle = New System.Windows.Forms.RadioButton()
        Me.rbFamily = New System.Windows.Forms.RadioButton()
        Me.chkGolf = New System.Windows.Forms.CheckBox()
        Me.chkTennis = New System.Windows.Forms.CheckBox()
        Me.chkRac = New System.Windows.Forms.CheckBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblBasic = New System.Windows.Forms.Label()
        Me.lblAdditional = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lblMonthly = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.btnCalc = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rbFamily)
        Me.GroupBox1.Controls.Add(Me.rbSingle)
        Me.GroupBox1.Location = New System.Drawing.Point(13, 13)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(113, 100)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Membership"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.chkRac)
        Me.GroupBox2.Controls.Add(Me.chkTennis)
        Me.GroupBox2.Controls.Add(Me.chkGolf)
        Me.GroupBox2.Location = New System.Drawing.Point(161, 13)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(113, 100)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Additional"
        '
        'rbSingle
        '
        Me.rbSingle.AutoSize = True
        Me.rbSingle.Location = New System.Drawing.Point(7, 20)
        Me.rbSingle.Name = "rbSingle"
        Me.rbSingle.Size = New System.Drawing.Size(54, 17)
        Me.rbSingle.TabIndex = 0
        Me.rbSingle.TabStop = True
        Me.rbSingle.Text = "&Single"
        Me.rbSingle.UseVisualStyleBackColor = True
        '
        'rbFamily
        '
        Me.rbFamily.AutoSize = True
        Me.rbFamily.Location = New System.Drawing.Point(7, 44)
        Me.rbFamily.Name = "rbFamily"
        Me.rbFamily.Size = New System.Drawing.Size(54, 17)
        Me.rbFamily.TabIndex = 1
        Me.rbFamily.TabStop = True
        Me.rbFamily.Text = "&Family"
        Me.rbFamily.UseVisualStyleBackColor = True
        '
        'chkGolf
        '
        Me.chkGolf.AutoSize = True
        Me.chkGolf.Location = New System.Drawing.Point(7, 20)
        Me.chkGolf.Name = "chkGolf"
        Me.chkGolf.Size = New System.Drawing.Size(45, 17)
        Me.chkGolf.TabIndex = 0
        Me.chkGolf.Text = "&Golf"
        Me.chkGolf.UseVisualStyleBackColor = True
        '
        'chkTennis
        '
        Me.chkTennis.AutoSize = True
        Me.chkTennis.Location = New System.Drawing.Point(7, 44)
        Me.chkTennis.Name = "chkTennis"
        Me.chkTennis.Size = New System.Drawing.Size(58, 17)
        Me.chkTennis.TabIndex = 1
        Me.chkTennis.Text = "&Tennis"
        Me.chkTennis.UseVisualStyleBackColor = True
        '
        'chkRac
        '
        Me.chkRac.AutoSize = True
        Me.chkRac.Location = New System.Drawing.Point(7, 68)
        Me.chkRac.Name = "chkRac"
        Me.chkRac.Size = New System.Drawing.Size(83, 17)
        Me.chkRac.TabIndex = 2
        Me.chkRac.Text = "&Racquetball"
        Me.chkRac.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 127)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(57, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Basic fee: "
        '
        'lblBasic
        '
        Me.lblBasic.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblBasic.Location = New System.Drawing.Point(12, 144)
        Me.lblBasic.Name = "lblBasic"
        Me.lblBasic.Size = New System.Drawing.Size(100, 23)
        Me.lblBasic.TabIndex = 3
        Me.lblBasic.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblAdditional
        '
        Me.lblAdditional.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblAdditional.Location = New System.Drawing.Point(163, 144)
        Me.lblAdditional.Name = "lblAdditional"
        Me.lblAdditional.Size = New System.Drawing.Size(100, 23)
        Me.lblAdditional.TabIndex = 5
        Me.lblAdditional.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(160, 127)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(59, 13)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "Additional: "
        '
        'lblMonthly
        '
        Me.lblMonthly.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblMonthly.Location = New System.Drawing.Point(11, 206)
        Me.lblMonthly.Name = "lblMonthly"
        Me.lblMonthly.Size = New System.Drawing.Size(101, 23)
        Me.lblMonthly.TabIndex = 7
        Me.lblMonthly.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(11, 190)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(76, 13)
        Me.Label6.TabIndex = 6
        Me.Label6.Text = "Monthly dues: "
        '
        'btnCalc
        '
        Me.btnCalc.Location = New System.Drawing.Point(129, 206)
        Me.btnCalc.Name = "btnCalc"
        Me.btnCalc.Size = New System.Drawing.Size(75, 23)
        Me.btnCalc.TabIndex = 8
        Me.btnCalc.Text = "&Calculate"
        Me.btnCalc.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(210, 206)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(64, 23)
        Me.btnExit.TabIndex = 9
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(288, 241)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnCalc)
        Me.Controls.Add(Me.lblMonthly)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.lblAdditional)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.lblBasic)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "frmMain"
        Me.Text = "Glasgow Health Club"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents rbFamily As RadioButton
    Friend WithEvents rbSingle As RadioButton
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents chkRac As CheckBox
    Friend WithEvents chkTennis As CheckBox
    Friend WithEvents chkGolf As CheckBox
    Friend WithEvents Label1 As Label
    Friend WithEvents lblBasic As Label
    Friend WithEvents lblAdditional As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents lblMonthly As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents btnCalc As Button
    Friend WithEvents btnExit As Button
End Class

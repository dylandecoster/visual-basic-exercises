﻿Public Class Dues
    Public Property Basic As Double
    Public Property Additional As Double

    Public Sub New()
        _Basic = 0
        _Additional = 0
    End Sub

    Public Sub New(ByVal basic As Double, ByVal additional As Double)
        _Basic = basic
        _Additional = additional
    End Sub

    Public Function Monthly() As Double
        Return _Basic + _Additional
    End Function
End Class

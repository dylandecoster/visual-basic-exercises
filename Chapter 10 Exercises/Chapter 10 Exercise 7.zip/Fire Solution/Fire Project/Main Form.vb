﻿'Name:          Fire Project
'Purpose:       Calculates the volume of a fire tank
'Programmer:    Dylan DeCoster on 11/4/19

Public Class frmMain
    Dim tank As Tank

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        'Inputs all the stuff
        tank = New Tank(Me.txtLength.Text, Me.txtWidth.Text, Me.txtHeight.Text)
        'Gets the gallons
        Me.lblGallons.Text = Val(tank.GetVolume).ToString("N1")
        'Gets the cubic feet
        Me.lblCubic.Text = Val(tank.GetVolume * 7.48).ToString("N1")
    End Sub
End Class

﻿Public Class Tank
    Private intLength As Double
    Private intWidth As Double
    Private intHeight As Double

    Public Property Length As Double
        Get
            Return intLength
        End Get
        Set(value As Double)
            If value > 0 Then
                intLength = value
            Else
                intLength = 0
            End If
        End Set
    End Property
    Public Property Width As Double
        Get
            Return intWidth
        End Get
        Set(value As Double)
            If value > 0 Then
                intWidth = value
            Else
                intWidth = 0
            End If
        End Set
    End Property
    Public Property Height As Double
        Get
            Return intHeight
        End Get
        Set(value As Double)
            If value > 0 Then
                intHeight = value
            Else
                intHeight = 0
            End If
        End Set
    End Property

    Public Sub New()
        intLength = 0
        intWidth = 0
        intHeight = 0
    End Sub

    Public Sub New(ByVal intL As Double, ByVal intW As Double, ByVal intH As Double)
        intLength = intL
        intWidth = intW
        intHeight = intH
    End Sub

    Public Function GetArea()
        Return intLength * intWidth
    End Function

    Public Function GetVolume()
        Return intLength * intWidth * intHeight
    End Function
End Class

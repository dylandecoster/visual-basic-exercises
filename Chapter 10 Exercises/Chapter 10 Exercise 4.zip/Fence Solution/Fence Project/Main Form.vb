﻿'Name:          Fence Project
'Purpose:       Calculate fence cost
'Programmer:    Dylan DeCoster on 11/4/19

Public Class frmMain
    Dim perimeter As Rectangle

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        'Inputs the length and width for the rectangle
        perimeter = New Rectangle(Me.txtLength.Text, Me.txtWidth.Text)
        'Gets the perimeter and multiplies it by the cost
        Me.lblCost.Text = "$" + (perimeter.GetPerimeter() * Me.txtCost.Text).ToString("N2")
    End Sub
End Class

﻿' Name:         Rectangle.vb
' Programmer:   Dylan DeCoster on 11/4/19

Option Explicit On
Option Strict On
Option Infer Off

Public Class Rectangle
    Private intLength As Double
    Private intWidth As Double

    Public Property Length As Double
        Get
            Return intLength
        End Get
        Set(value As Double)
            If value > 0 Then
                intLength = value
            Else
                intLength = 0
            End If
        End Set
    End Property

    Public Property Width As Double
        Get
            Return intWidth
        End Get
        Set(value As Double)
            If value > 0 Then
                intWidth = value
            Else
                intWidth = 0
            End If
        End Set
    End Property

    Public Sub New()
        intLength = 0
        intWidth = 0
    End Sub

    Public Sub New(ByVal intL As Double, ByVal intW As Double)
        Length = intL
        Width = intW
    End Sub

    Public Function GetArea() As Double
        Return intLength * intWidth
    End Function

    Public Function GetPerimeter() As Double
        Return (intLength + intWidth) * 2
    End Function
End Class

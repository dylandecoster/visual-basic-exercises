﻿' Name:         Employee.vb
' Programmer:   Dylan DeCoster on 11/5/19

Option Explicit On
Option Strict On
Option Infer Off

Public Class Employee
    Public Property EmployeeName As String
    Public Property Salary As Double

    Public Sub New()
        _EmployeeName = String.Empty
        _Salary = 0
    End Sub

    Public Sub New(ByVal name As String, ByVal salary As Double)
        _EmployeeName = name
        _Salary = salary
    End Sub

    Public Function GetNewSalary() As Double
        ' Calculates the new salary.

        Return _Salary + (_Salary * 0.05)
    End Function
End Class

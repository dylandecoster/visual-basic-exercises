﻿'Name:          Parking Lot
'Purpose:       Calculates cost of parking lot
'Programmer:    Dylan DeCoster on 11/4/19

Public Class frmMain
    Dim lot As Lot

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnCalc.Click, btnCalc.Click
        'Makes a new lot with the input
        lot = New Lot(Me.txtBase.Text, Me.txtHeight.Text)
        'Gets the cost
        Me.lblCost.Text = "$" + ((lot.GetArea * txtCost.Text) / 9).ToString("N2")
    End Sub
End Class

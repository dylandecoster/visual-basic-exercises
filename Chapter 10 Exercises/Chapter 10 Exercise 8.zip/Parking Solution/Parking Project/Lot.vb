﻿Public Class Lot
    Private intBase As Double
    Private intHeight As Double

    Public Property Base As Double
        Get
            Return intBase
        End Get
        Set(value As Double)
            If value > 0 Then
                intBase = value
            Else
                intBase = 0
            End If
        End Set
    End Property

    Public Property Height As Double
        Get
            Return intHeight
        End Get
        Set(value As Double)
            If value > 0 Then
                intHeight = value
            Else
                intHeight = 0
            End If
        End Set
    End Property

    Public Sub New()
        intBase = 0
        intHeight = 0
    End Sub

    Public Sub New(ByVal intB As Double, ByVal intH As Double)
        intBase = intB
        intHeight = intH
    End Sub

    Public Function GetArea() As Double
        Return intBase * intHeight
    End Function
End Class

﻿Public Class Triangle
    Private dubBase As Double
    Private dubHeight As Double

    'Checks the base and height are greater than 0
    Public Property Base As Double
        Get
            Return dubBase
        End Get
        Set(value As Double)
            If value > 0 Then
                dubBase = value
            Else
                dubBase = 0
            End If
        End Set
    End Property

    Public Property Height As Double
        Get
            Return dubHeight
        End Get
        Set(value As Double)
            If value > 0 Then
                dubHeight = value
            Else
                dubHeight = 0
            End If
        End Set
    End Property

    'Basic constructor
    Public Sub New()
        dubBase = 0
        dubHeight = 0
    End Sub

    'Constructor with parameters
    Public Sub New(ByVal dubB As Integer, ByVal dubH As Integer)
        dubBase = dubB
        dubHeight = dubH
    End Sub

    'Calculates the area of the triangle
    Public Function GetArea() As Double
        Return (dubBase * dubHeight) * 0.5
    End Function
End Class

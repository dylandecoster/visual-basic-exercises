﻿'Name:          Playground Project
'Purpose:       Calculate cost on playground
'Programmer:    Dylan DeCoster on 11/4/19

Public Class frmMain
    Dim area As Triangle

    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        'Inputs all the parameters for the triangle
        area = New Triangle(Me.lstBase.SelectedItem, Me.lstHeight.SelectedItem)
        'Calculates the cost
        Me.lblCost.Text = "$" + Val(area.GetArea * lstPrice.SelectedItem).ToString("N2")
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Sets all the list box numbers
        For dimensions As Double = 20 To 50 Step 0.5
            Me.lstBase.Items.Add(dimensions.ToString("N1"))
            Me.lstHeight.Items.Add(dimensions.ToString("N1"))
        Next dimensions

        For lstPrice As Double = 1 To 6 Step 0.5
            Me.lstPrice.Items.Add(lstPrice.ToString("N1"))
        Next lstPrice
    End Sub
End Class

﻿'Name:          Sod Project
'Purpose:       Calculate sod price per square yard
'Programmer:    Dylan DeCoster on 11/4/19

Public Class frmMain
    Dim price As Rectangle

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        'Puts the length and width from the input into the rectangle
        price = New Rectangle(Me.txtLength.Text, Me.txtFeet.Text)
        'Gets the price and divides it by the price per sq yd and divides it by 9
        Me.lblPrice.Text = "$" + ((price.GetArea() / Me.txtPrice.Text) / 9).ToString("N2")
    End Sub
End Class

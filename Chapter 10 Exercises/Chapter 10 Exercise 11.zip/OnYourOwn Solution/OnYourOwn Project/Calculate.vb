﻿Public Class Calculate
    Public Property num As Integer
    Dim str As String

    Public Sub New()
        num = 0
    End Sub

    Public Sub New(ByVal intNum)
        num = intNum
    End Sub

    Public Function Math() As String
        'Checks if the number is even or odd
        If num Mod 2 = 0 Then
            str = "Even"
        Else
            str = "Odd"
        End If

        Return str
    End Function
End Class

﻿'Name:          Calculate Project
'Purpose:       Check if a number is even or odd
'Programmer:    Dylan DeCoster on 11/5/19

Public Class frmMain
    Dim calc As Calculate

    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        'Inputs the users number
        calc = New Calculate(Val(Me.txtEnter.Text))
        'Calculates the thing
        Me.lblAnswer.Text = calc.Math
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class

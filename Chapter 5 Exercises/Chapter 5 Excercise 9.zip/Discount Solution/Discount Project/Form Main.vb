﻿'Name:          Discount Warehouse
'Purpose:       Calculates the discount
'Programmer:    Dylan DeCoster on 10/16/19

Public Class frmMain
    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        Dim intNum As Integer = 10
        Dim price, percent As Double

        price = Val(Me.txtPrice.Text)

        'Finds which percent you selected
        Do While intNum <= 40
            'If intNum is the correct percent it gets the percent
            If (intNum.ToString() = lbRate.SelectedItem) Then
                percent = lbRate.SelectedItem / 100
            End If

            intNum += 5
        Loop

        'Gets the percent and calculates all the crap
        Me.lblDiscount.Text = "$" + (price - (price * percent)).ToString("N2")
        Me.lblAmount.Text = "$" + (price * percent).ToString("N2")
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()

    End Sub
End Class

﻿Public Class frmMain
    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lbStates.SelectedIndexChanged
        If (Me.lbStates.SelectedItem = "Oklahoma") Then
            Me.lblCapital.Text = "Oklahoma City"
        ElseIf (Me.lbStates.SelectedItem = "Alabama") Then
            Me.lblCapital.Text = "Montgomery"
        ElseIf (Me.lbStates.SelectedItem = "Kansas") Then
            Me.lblCapital.Text = "Topeka"
        ElseIf (Me.lbStates.SelectedItem = "Kentucky") Then
            Me.lblCapital.Text = "Frankfort"
        ElseIf (Me.lbStates.SelectedItem = "Mississippi") Then
            Me.lblCapital.Text = "Jackson"
        End If
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()

    End Sub
End Class

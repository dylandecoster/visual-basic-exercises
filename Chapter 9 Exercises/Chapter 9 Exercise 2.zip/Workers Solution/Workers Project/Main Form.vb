﻿' Name:         Workers Project
' Purpose:      Saves worker names to a sequential access files.
' Programmer:   Dylan DeCoster on 10/29/19

Option Explicit On
Option Strict On
Option Infer Off

Public Class frmMain
    Dim outfile As IO.StreamWriter
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub txtName_Enter(sender As Object, e As EventArgs) Handles txtName.Enter
        txtName.SelectAll()
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Dim name As String
        name = Me.txtName.Text
        'Adds a new item to the list
        Me.lstWorkers.Items.Add(name)
    End Sub

    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Replaces the file with a new one
        outfile = IO.File.CreateText("workers.txt")
        outfile.Close()
    End Sub

    Private Sub frmMain_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        'Allows you to edit the text
        outfile = IO.File.AppendText("workers.txt")

        'Repeats for every listbox item
        For intList As Integer = 0 To lstWorkers.Items.Count - 1
            'Gets the item and prints it in the file
            outfile.WriteLine(lstWorkers.Items.Item(intList))
        Next intList

        outfile.Close()
    End Sub
End Class

﻿'Name:          Customers Project
'Purpose:       Read customer data and save it to an external txt file
'Programmer:    Dylan DeCoster on 10/30/19

Public Class frmMain
    Dim outFile As IO.StreamWriter
    Dim fullName As String
    Dim address As String

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()
    End Sub

    'Shows the message saved label
    Private Sub Message(sender As Object, e As EventArgs) _
        Handles txtFirst.TextChanged, txtAddress.TextChanged, txtCity.TextChanged, txtLast.TextChanged, txtZIP.TextChanged
        Me.lblMessage.Visible = False
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        'Checks if everything is filled in and if not a message box shows up
        If txtFirst.Text = Nothing Or txtLast.Text = Nothing Or txtAddress.Text = Nothing Or txtCity.Text = Nothing Or txtZIP.Text = Nothing Then
            MessageBox.Show("One or more fields are empty.", "Customer Information", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            'Else it saves everything to the variables correctly
        Else
            fullName = Me.txtFirst.Text + Me.txtLast.Text
            address = Me.txtAddress.Text + ", " + Me.txtCity.Text + ", " + Me.txtZIP.Text
            Me.lblMessage.Visible = True
        End If

        'Edits the txt
        outFile = IO.File.AppendText("customers.txt")
        'Writes the name on a new line
        outFile.WriteLine(fullName)
        'Writes the address on a new line
        outFile.WriteLine(address)
        'Makes a new empty line to seperate customers
        outFile.WriteLine()
        'Closes the txt
        outFile.Close()
    End Sub

    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Makes a new txt
        outFile = IO.File.CreateText("customers.txt")
        'Closes it
        outFile.Close()
    End Sub
End Class

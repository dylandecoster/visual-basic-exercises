﻿'Name:          Potter Jr High
'Purpose:       Import stuff from external file and print stuff
'Programmer:    Dylan DeCoster on 10/30/19

Public Class frmMain
    Dim index As Integer = 0
    Dim students(30) As String
    Dim num As Integer


    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.lstGrades.SelectedIndex = 0

        Dim inFile As IO.StreamReader
        'If the file exists then
        If IO.File.Exists("NamesAndGrades.txt") Then
            'Opens the file
            inFile = IO.File.OpenText("NamesAndGrades.txt")
            'Repeats until there is no more lines left to read
            Do Until inFile.Peek = -1
                'Adds that line to the students array
                students(index) = inFile.ReadLine
                'Adds 1 to index
                index += 1
            Loop
            'Closes that file
            inFile.Close()
        Else
            MessageBox.Show("Cannot find the file.", "Potter Jr High", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
    End Sub

    Private Sub lstGrades_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstGrades.SelectedIndexChanged
        'Clears everything
        Me.lstNames.Items.Clear()
        Me.lblNumber.Text = Nothing
    End Sub

    Private Sub btnDisplay_Click(sender As Object, e As EventArgs) Handles btnDisplay.Click
        'Repeats the length of the array
        For intIndex As Integer = 0 To 29
            'If the grade is the same as the selected grade then
            If students(intIndex) = Me.lstGrades.SelectedItem Then
                num += 1
                'Adds the students name to the list box
                Me.lstNames.Items.Add(students(intIndex - 1))
            End If
        Next intIndex
        'Prints the number
        Me.lblNumber.Text = num.ToString()
        num = 0
    End Sub
End Class

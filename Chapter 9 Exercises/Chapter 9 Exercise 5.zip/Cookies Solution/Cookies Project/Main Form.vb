﻿'Name:          Cookie Sales
'Purpose:       Calculate amount of cookies in total
'Programmer:    Dylan DeCoster on 11/1/19

Public Class frmMain
    Dim inFile As IO.StreamReader
    Dim cookies(3) As Integer
    Dim i As Integer = 0
    Dim cookieSales(20) As String

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnTotal.Click
        'Repeats the length of the text file
        For intNum As Integer = 0 To cookieSales.Length - 1
            'Calculates the amount of cookies by type
            If (cookieSales(intNum) = "Chocolate chip") Then
                cookies(0) += cookieSales(intNum + 1)
            ElseIf cookieSales(intNum) = "Oatmeal" Then
                cookies(1) += cookieSales(intNum + 1)
            ElseIf cookieSales(intNum) = "Peanut butter" Then
                cookies(2) += cookieSales(intNum + 1)
            ElseIf cookieSales(intNum) = "Sugar" Then
                cookies(3) += cookieSales(intNum + 1)
            End If
        Next intNum

        'Prints everything
        Me.lblChocolate.Text = cookies(0)
        Me.lblOatmeal.Text = cookies(1)
        Me.lblPeanut.Text = cookies(2)
        Me.lblSugar.Text = cookies(3)
    End Sub

    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'If the file exists
        If IO.File.Exists("cookieSales.txt") Then
            'Opens the file
            inFile = IO.File.OpenText("cookieSales.txt")
            'Reads every line of the file
            Do Until inFile.Peek = -1
                'Stores the file into the array
                cookieSales(i) = inFile.ReadLine
                i += 1
            Loop
            'Closes the file
            inFile.Close()
        Else
            'Shows an error message box
            MessageBox.Show("Cannot find the file.", "Cookies", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
    End Sub
End Class

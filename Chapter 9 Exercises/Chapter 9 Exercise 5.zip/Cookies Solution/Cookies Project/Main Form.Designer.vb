﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblChocolate = New System.Windows.Forms.Label()
        Me.lblOatmeal = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lblPeanut = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.lblSugar = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.btnTotal = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.lblSugar)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.lblPeanut)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.lblOatmeal)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.lblChocolate)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(13, 13)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(341, 86)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Boxes sold"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(7, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(84, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Chocolate chip: "
        '
        'lblChocolate
        '
        Me.lblChocolate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblChocolate.Location = New System.Drawing.Point(10, 37)
        Me.lblChocolate.Name = "lblChocolate"
        Me.lblChocolate.Size = New System.Drawing.Size(57, 23)
        Me.lblChocolate.TabIndex = 1
        Me.lblChocolate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblOatmeal
        '
        Me.lblOatmeal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblOatmeal.Location = New System.Drawing.Point(100, 37)
        Me.lblOatmeal.Name = "lblOatmeal"
        Me.lblOatmeal.Size = New System.Drawing.Size(57, 23)
        Me.lblOatmeal.TabIndex = 3
        Me.lblOatmeal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(97, 20)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(52, 13)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "Oatmeal: "
        '
        'lblPeanut
        '
        Me.lblPeanut.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblPeanut.Location = New System.Drawing.Point(193, 37)
        Me.lblPeanut.Name = "lblPeanut"
        Me.lblPeanut.Size = New System.Drawing.Size(57, 23)
        Me.lblPeanut.TabIndex = 5
        Me.lblPeanut.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(190, 20)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(77, 13)
        Me.Label6.TabIndex = 4
        Me.Label6.Text = "Peanut butter: "
        '
        'lblSugar
        '
        Me.lblSugar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSugar.Location = New System.Drawing.Point(276, 37)
        Me.lblSugar.Name = "lblSugar"
        Me.lblSugar.Size = New System.Drawing.Size(57, 23)
        Me.lblSugar.TabIndex = 7
        Me.lblSugar.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(273, 20)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(41, 13)
        Me.Label8.TabIndex = 6
        Me.Label8.Text = "Sugar: "
        '
        'btnTotal
        '
        Me.btnTotal.Location = New System.Drawing.Point(183, 121)
        Me.btnTotal.Name = "btnTotal"
        Me.btnTotal.Size = New System.Drawing.Size(90, 23)
        Me.btnTotal.TabIndex = 1
        Me.btnTotal.Text = "&Display totals"
        Me.btnTotal.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(279, 120)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 2
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(369, 163)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnTotal)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "frmMain"
        Me.Text = "Cookie Sales"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents lblSugar As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents lblPeanut As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents lblOatmeal As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents lblChocolate As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents btnTotal As Button
    Friend WithEvents btnExit As Button
End Class

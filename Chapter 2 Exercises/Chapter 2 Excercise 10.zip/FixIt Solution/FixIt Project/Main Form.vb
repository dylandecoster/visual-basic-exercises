﻿' Name:         FixIt Project
' Purpose:      Allows the user to enter a name.
' Programmer:   <your name> on <currrent date>

Public Class frmMain
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class

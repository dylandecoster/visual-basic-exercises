﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnCalc = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.txtMartin = New System.Windows.Forms.TextBox()
        Me.txtKaren = New System.Windows.Forms.TextBox()
        Me.txtJim = New System.Windows.Forms.TextBox()
        Me.lblJim = New System.Windows.Forms.Label()
        Me.lblKaren = New System.Windows.Forms.Label()
        Me.lblMartin = New System.Windows.Forms.Label()
        Me.lblPercent = New System.Windows.Forms.Label()
        Me.lblTotal = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnCalc
        '
        Me.btnCalc.Location = New System.Drawing.Point(172, 69)
        Me.btnCalc.Name = "btnCalc"
        Me.btnCalc.Size = New System.Drawing.Size(75, 23)
        Me.btnCalc.TabIndex = 4
        Me.btnCalc.Text = "Calculate"
        Me.btnCalc.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(172, 130)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 5
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'txtMartin
        '
        Me.txtMartin.Location = New System.Drawing.Point(12, 72)
        Me.txtMartin.Name = "txtMartin"
        Me.txtMartin.Size = New System.Drawing.Size(100, 20)
        Me.txtMartin.TabIndex = 3
        '
        'txtKaren
        '
        Me.txtKaren.Location = New System.Drawing.Point(147, 28)
        Me.txtKaren.Name = "txtKaren"
        Me.txtKaren.Size = New System.Drawing.Size(100, 20)
        Me.txtKaren.TabIndex = 2
        '
        'txtJim
        '
        Me.txtJim.Location = New System.Drawing.Point(12, 28)
        Me.txtJim.Name = "txtJim"
        Me.txtJim.Size = New System.Drawing.Size(100, 20)
        Me.txtJim.TabIndex = 1
        '
        'lblJim
        '
        Me.lblJim.AutoSize = True
        Me.lblJim.Location = New System.Drawing.Point(9, 12)
        Me.lblJim.Name = "lblJim"
        Me.lblJim.Size = New System.Drawing.Size(64, 13)
        Me.lblJim.TabIndex = 5
        Me.lblJim.Text = "Jim's Sales: "
        '
        'lblKaren
        '
        Me.lblKaren.AutoSize = True
        Me.lblKaren.Location = New System.Drawing.Point(144, 12)
        Me.lblKaren.Name = "lblKaren"
        Me.lblKaren.Size = New System.Drawing.Size(77, 13)
        Me.lblKaren.TabIndex = 6
        Me.lblKaren.Text = "Karen's Sales: "
        '
        'lblMartin
        '
        Me.lblMartin.AutoSize = True
        Me.lblMartin.Location = New System.Drawing.Point(9, 56)
        Me.lblMartin.Name = "lblMartin"
        Me.lblMartin.Size = New System.Drawing.Size(78, 13)
        Me.lblMartin.TabIndex = 7
        Me.lblMartin.Text = "Martin's Sales: "
        '
        'lblPercent
        '
        Me.lblPercent.AutoSize = True
        Me.lblPercent.Location = New System.Drawing.Point(12, 113)
        Me.lblPercent.Name = "lblPercent"
        Me.lblPercent.Size = New System.Drawing.Size(68, 13)
        Me.lblPercent.TabIndex = 8
        Me.lblPercent.Text = "Percentage: "
        '
        'lblTotal
        '
        Me.lblTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTotal.Location = New System.Drawing.Point(12, 130)
        Me.lblTotal.Name = "lblTotal"
        Me.lblTotal.Size = New System.Drawing.Size(100, 23)
        Me.lblTotal.TabIndex = 9
        Me.lblTotal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(256, 169)
        Me.Controls.Add(Me.lblTotal)
        Me.Controls.Add(Me.lblPercent)
        Me.Controls.Add(Me.lblMartin)
        Me.Controls.Add(Me.lblKaren)
        Me.Controls.Add(Me.lblJim)
        Me.Controls.Add(Me.txtJim)
        Me.Controls.Add(Me.txtKaren)
        Me.Controls.Add(Me.txtMartin)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnCalc)
        Me.Name = "frmMain"
        Me.Text = "Sales"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnCalc As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents txtMartin As TextBox
    Friend WithEvents txtKaren As TextBox
    Friend WithEvents txtJim As TextBox
    Friend WithEvents lblJim As Label
    Friend WithEvents lblKaren As Label
    Friend WithEvents lblMartin As Label
    Friend WithEvents lblPercent As Label
    Friend WithEvents lblTotal As Label
End Class

﻿'Project: Sales Project
'Purpose: Create an interface that calculates the percent of total sales from the three people
'Programmer: Dylan DeCoster on 10/9/19

Public Class frmMain
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()

    End Sub
End Class

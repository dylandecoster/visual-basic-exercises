﻿'Project: Kramden Inc.
'Purpose: Calculate expenses
'Name: Dylan DeCoster on 10/8/19

Public Class frmMain
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()

    End Sub
End Class

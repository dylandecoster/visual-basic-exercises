﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtLength = New System.Windows.Forms.TextBox()
        Me.txtWidth = New System.Windows.Forms.TextBox()
        Me.lblLength = New System.Windows.Forms.Label()
        Me.lblWidth = New System.Windows.Forms.Label()
        Me.btnCalc = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblTitleFeet = New System.Windows.Forms.Label()
        Me.lblTitleYards = New System.Windows.Forms.Label()
        Me.lblFeet = New System.Windows.Forms.Label()
        Me.lblYards = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'txtLength
        '
        Me.txtLength.Location = New System.Drawing.Point(62, 37)
        Me.txtLength.Name = "txtLength"
        Me.txtLength.Size = New System.Drawing.Size(100, 20)
        Me.txtLength.TabIndex = 1
        '
        'txtWidth
        '
        Me.txtWidth.Location = New System.Drawing.Point(62, 70)
        Me.txtWidth.Name = "txtWidth"
        Me.txtWidth.Size = New System.Drawing.Size(100, 20)
        Me.txtWidth.TabIndex = 2
        '
        'lblLength
        '
        Me.lblLength.AutoSize = True
        Me.lblLength.Location = New System.Drawing.Point(13, 40)
        Me.lblLength.Name = "lblLength"
        Me.lblLength.Size = New System.Drawing.Size(43, 13)
        Me.lblLength.TabIndex = 2
        Me.lblLength.Text = "Length:"
        '
        'lblWidth
        '
        Me.lblWidth.AutoSize = True
        Me.lblWidth.Location = New System.Drawing.Point(15, 73)
        Me.lblWidth.Name = "lblWidth"
        Me.lblWidth.Size = New System.Drawing.Size(41, 13)
        Me.lblWidth.TabIndex = 3
        Me.lblWidth.Text = "Width: "
        '
        'btnCalc
        '
        Me.btnCalc.Location = New System.Drawing.Point(202, 67)
        Me.btnCalc.Name = "btnCalc"
        Me.btnCalc.Size = New System.Drawing.Size(75, 23)
        Me.btnCalc.TabIndex = 3
        Me.btnCalc.Text = "Calculate"
        Me.btnCalc.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(202, 145)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 6
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lblTitleFeet
        '
        Me.lblTitleFeet.AutoSize = True
        Me.lblTitleFeet.Location = New System.Drawing.Point(13, 125)
        Me.lblTitleFeet.Name = "lblTitleFeet"
        Me.lblTitleFeet.Size = New System.Drawing.Size(70, 13)
        Me.lblTitleFeet.TabIndex = 6
        Me.lblTitleFeet.Text = "Area in Feet: "
        '
        'lblTitleYards
        '
        Me.lblTitleYards.AutoSize = True
        Me.lblTitleYards.Location = New System.Drawing.Point(105, 125)
        Me.lblTitleYards.Name = "lblTitleYards"
        Me.lblTitleYards.Size = New System.Drawing.Size(76, 13)
        Me.lblTitleYards.TabIndex = 7
        Me.lblTitleYards.Text = "Area in Yards: "
        '
        'lblFeet
        '
        Me.lblFeet.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblFeet.Location = New System.Drawing.Point(12, 145)
        Me.lblFeet.Name = "lblFeet"
        Me.lblFeet.Size = New System.Drawing.Size(71, 23)
        Me.lblFeet.TabIndex = 4
        Me.lblFeet.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblYards
        '
        Me.lblYards.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblYards.Location = New System.Drawing.Point(108, 145)
        Me.lblYards.Name = "lblYards"
        Me.lblYards.Size = New System.Drawing.Size(73, 23)
        Me.lblYards.TabIndex = 5
        Me.lblYards.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(289, 189)
        Me.Controls.Add(Me.lblYards)
        Me.Controls.Add(Me.lblFeet)
        Me.Controls.Add(Me.lblTitleYards)
        Me.Controls.Add(Me.lblTitleFeet)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnCalc)
        Me.Controls.Add(Me.lblWidth)
        Me.Controls.Add(Me.lblLength)
        Me.Controls.Add(Me.txtWidth)
        Me.Controls.Add(Me.txtLength)
        Me.Name = "frmMain"
        Me.Text = "Area Project"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtLength As TextBox
    Friend WithEvents txtWidth As TextBox
    Friend WithEvents lblLength As Label
    Friend WithEvents lblWidth As Label
    Friend WithEvents btnCalc As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents lblTitleFeet As Label
    Friend WithEvents lblTitleYards As Label
    Friend WithEvents lblFeet As Label
    Friend WithEvents lblYards As Label
End Class

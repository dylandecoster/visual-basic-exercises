﻿'Project: Grade Project
'Purpose: Make the interface for calculating grades
'Programmer: Dylan DeCoster on 10/9/19

Public Class frmMain
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()

    End Sub
End Class

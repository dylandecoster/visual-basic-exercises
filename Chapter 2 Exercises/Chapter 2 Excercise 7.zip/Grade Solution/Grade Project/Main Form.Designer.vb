﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnCalc = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblPass = New System.Windows.Forms.Label()
        Me.lblFail = New System.Windows.Forms.Label()
        Me.txtPass = New System.Windows.Forms.TextBox()
        Me.txtFail = New System.Windows.Forms.TextBox()
        Me.lblPassPer = New System.Windows.Forms.Label()
        Me.lblPassing = New System.Windows.Forms.Label()
        Me.lblFailing = New System.Windows.Forms.Label()
        Me.lblFailPer = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnCalc
        '
        Me.btnCalc.Location = New System.Drawing.Point(272, 25)
        Me.btnCalc.Name = "btnCalc"
        Me.btnCalc.Size = New System.Drawing.Size(75, 23)
        Me.btnCalc.TabIndex = 3
        Me.btnCalc.Text = "Calculate"
        Me.btnCalc.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(272, 94)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 4
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lblPass
        '
        Me.lblPass.AutoSize = True
        Me.lblPass.Location = New System.Drawing.Point(12, 9)
        Me.lblPass.Name = "lblPass"
        Me.lblPass.Size = New System.Drawing.Size(95, 13)
        Me.lblPass.TabIndex = 2
        Me.lblPass.Text = "Passing Students: "
        '
        'lblFail
        '
        Me.lblFail.AutoSize = True
        Me.lblFail.Location = New System.Drawing.Point(126, 9)
        Me.lblFail.Name = "lblFail"
        Me.lblFail.Size = New System.Drawing.Size(88, 13)
        Me.lblFail.TabIndex = 3
        Me.lblFail.Text = "Failing Students: "
        '
        'txtPass
        '
        Me.txtPass.Location = New System.Drawing.Point(15, 25)
        Me.txtPass.Name = "txtPass"
        Me.txtPass.Size = New System.Drawing.Size(100, 20)
        Me.txtPass.TabIndex = 1
        '
        'txtFail
        '
        Me.txtFail.Location = New System.Drawing.Point(129, 25)
        Me.txtFail.Name = "txtFail"
        Me.txtFail.Size = New System.Drawing.Size(100, 20)
        Me.txtFail.TabIndex = 2
        '
        'lblPassPer
        '
        Me.lblPassPer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblPassPer.Location = New System.Drawing.Point(13, 94)
        Me.lblPassPer.Name = "lblPassPer"
        Me.lblPassPer.Size = New System.Drawing.Size(100, 23)
        Me.lblPassPer.TabIndex = 6
        Me.lblPassPer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblPassing
        '
        Me.lblPassing.AutoSize = True
        Me.lblPassing.Location = New System.Drawing.Point(12, 77)
        Me.lblPassing.Name = "lblPassing"
        Me.lblPassing.Size = New System.Drawing.Size(108, 13)
        Me.lblPassing.TabIndex = 7
        Me.lblPassing.Text = "Percentage Passing: "
        '
        'lblFailing
        '
        Me.lblFailing.AutoSize = True
        Me.lblFailing.Location = New System.Drawing.Point(128, 77)
        Me.lblFailing.Name = "lblFailing"
        Me.lblFailing.Size = New System.Drawing.Size(101, 13)
        Me.lblFailing.TabIndex = 8
        Me.lblFailing.Text = "Percentage Failing: "
        '
        'lblFailPer
        '
        Me.lblFailPer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblFailPer.Location = New System.Drawing.Point(128, 94)
        Me.lblFailPer.Name = "lblFailPer"
        Me.lblFailPer.Size = New System.Drawing.Size(100, 23)
        Me.lblFailPer.TabIndex = 9
        Me.lblFailPer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(369, 136)
        Me.Controls.Add(Me.lblFailPer)
        Me.Controls.Add(Me.lblFailing)
        Me.Controls.Add(Me.lblPassing)
        Me.Controls.Add(Me.lblPassPer)
        Me.Controls.Add(Me.txtFail)
        Me.Controls.Add(Me.txtPass)
        Me.Controls.Add(Me.lblFail)
        Me.Controls.Add(Me.lblPass)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnCalc)
        Me.Name = "frmMain"
        Me.Text = "Grade"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnCalc As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents lblPass As Label
    Friend WithEvents lblFail As Label
    Friend WithEvents txtPass As TextBox
    Friend WithEvents txtFail As TextBox
    Friend WithEvents lblPassPer As Label
    Friend WithEvents lblPassing As Label
    Friend WithEvents lblFailing As Label
    Friend WithEvents lblFailPer As Label
End Class
